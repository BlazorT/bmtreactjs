CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int DEFAULT NULL,
  `FirstName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `LastName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CityId` int DEFAULT NULL,
  `Address1` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Address2` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ZipPostalCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PhoneNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `FaxNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `AddressTypeId` int DEFAULT NULL,
  `CustomAttributes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CreatedAt` datetime NOT NULL,
  `RowVer` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1028,1,'Taymullah','Rehman','Taymullah@gmail.com',1,'Villa# 2011',NULL,NULL,'973001001',NULL,NULL,NULL,'2020-07-08 16:24:54',NULL),(8050,13083,'Nouman','Khan','nouman.alikhan@gmail.com',5,'75 miles (120 km) Alexander City, USA',NULL,'3453453','+928005687734534','+3455345343343',1,NULL,'2020-09-13 17:10:26',1),(8051,13084,'Afifa','Fatima','afifa.fatima12@gmail.com',1,'20 miles (32.2 km) north of downtown Dallas',NULL,'93501','+434534534533','+823452342234',1,NULL,'2020-09-13 17:25:00',1),(8052,13085,'Muhammad','Ghani','muhammad.ghani12@gmail.com',3,'3333 Raleigh St, Houston, TX 77021, United States',NULL,'935464','+843534534','+3455476573',1,NULL,'2020-09-13 17:30:49',1),(11056,14096,'Adnan','Rafiq','adnan.ali@gmail.com',2,'Texas','Boston',NULL,'+9234456789',NULL,1,NULL,'2020-11-17 17:22:22',1),(11057,14098,'Ahmad','Akhtar','ahmad.akhtar@gmail.com',1,'new Lahore','new Lahore','123423','+923030427435','+923334455678',1,NULL,'2020-11-17 17:43:34',1),(12063,15122,'William','Smith','willwam.smith12@gmail.com',1,'Boston','Boston',NULL,'+93456778890',NULL,1,NULL,'2020-11-21 15:25:33',1),(12064,15123,'John','Virk','john.virk990@hotmail.com',2,'Texas','Boston',NULL,'+923345567845',NULL,1,NULL,'2020-11-21 15:28:45',1),(12065,15124,'John','Virk','john.virk12@gmail.com',2,'Texas','Boston',NULL,'+923334433212',NULL,1,NULL,'2020-11-21 15:30:43',1),(12066,15125,'Alexander','Smith','alexander.smith12@gmail.com',1,'Boston','Boston',NULL,'+923455566789',NULL,1,NULL,'2020-11-21 15:32:06',1),(12071,15130,'Khadija','ALi','khadija.Nasreen@gmail.com',1,'Johar Town Lahore',NULL,NULL,'+1334455172',NULL,NULL,NULL,'2020-11-23 12:35:54',NULL),(12072,15131,'Abrar','Nazir','abrar.nazir@gmail.com',2,'100/ Ali Block Lahore','Boston',NULL,'+923000743230',NULL,1,NULL,'2020-11-23 12:46:20',1),(12076,15136,'Umair','Ali','umair.arshad@gmail.com',5,'Gareen Town Lahore',NULL,NULL,'+1334455172',NULL,NULL,NULL,'2020-11-26 10:17:18',NULL),(12077,15137,'Muhammad','Ayaz','merchantymc@joinymc.com',2,'100 Aalam Msaon','100 Aalam Msaon',NULL,'9730019919','9730019919',NULL,NULL,'2020-11-26 11:13:49',NULL),(13076,16135,'Faculty','Member','facultyymc@joinymc.com',1,'Boston',NULL,NULL,'+9234345435402','+9234345435402',NULL,NULL,'2020-11-26 14:52:19',NULL),(13077,16136,'Merchant','YMC','tayler.john@gmail.com',2,'Texas',NULL,NULL,'+19730019916','+19730019916',NULL,NULL,'2020-11-26 15:04:36',NULL),(13078,16137,'Nick','anthony','nick.brandon@gmail.com',1,'1149 W 13th St, Jacksonville, FL 32209, United States','Boston',NULL,'+923045566890',NULL,1,NULL,'2020-11-26 15:09:03',1),(13089,16155,'John','Doe','info@joinymc.com',1,'Boston Tetiure, modified by development team',NULL,'10020','+19730019919','+19730019919',NULL,NULL,'2020-12-04 16:58:54',NULL),(13090,16156,'John','Doe','muhammad.almas@gmail.com',3,'New Street','New Street',NULL,'123445567','123445567',NULL,NULL,'2020-12-04 17:35:18',NULL),(15089,15126,'Arshad','Ali','arshaad.ali@gmail.com',5,'Gareen Town Lahore',NULL,NULL,'+13334353453',NULL,NULL,NULL,'2020-11-23 11:10:38',NULL),(15090,17156,'Arshad','Zulifqar','arshad.ali@gmail.com',2,'Ittefaq Town Lahore',NULL,NULL,'3040427435',NULL,NULL,NULL,'2020-12-10 14:17:44',NULL),(17093,18163,'kasab','bawani','znawazch@gmail.com',1,'100 Ali Block, Lahore','100 Ali Block, Lahore',NULL,'9723034353','9723034353',NULL,NULL,'2020-12-16 16:06:37',NULL),(18099,19180,'Saleh','Bakr','muhammad.almas172@gmail.com',2,'Heights, Masatrta, Texas','Heights, Masatrta, Texas','12095','9732410029',NULL,1,NULL,'2021-01-04 15:33:42',1),(18100,19194,'Anthonys','Benjamins','ayaan.jamshaid172@gmail.com',2,'xxx','xxx',NULL,'973120098','973120098',NULL,NULL,'2021-01-04 16:33:46',NULL),(19096,20171,'Saleh','Bakr','muhammad.almas172@gmail.com',1,'19 West New Street Plano','19 West New Street Plano','17200','+122334455',NULL,1,NULL,'2021-01-11 17:22:16',1),(19097,20172,'Josephs','Davids','aalmasch8125@gmail.com',2,'04 West 1st Street Dallas','04 West 1st Street Dallas',NULL,'166778899','166778899',NULL,NULL,'2021-01-11 17:52:01',NULL),(19098,20175,'Parker','Wesley','almas.arshad172@hotmail.com',1,'05 West New Street 20 No','05 West New Street 20 No',NULL,'99887766','99887766',NULL,NULL,'2021-01-11 17:52:01',NULL),(19099,20176,'Muhammad','Arshad','almas.arshad17200@gmail.com',4,'100 ALi Block Model Town',NULL,NULL,'+3042676412',NULL,1,NULL,'2021-01-11 18:53:36',1),(19100,20177,'Saleh','Bakr','muhammad.almas172@gmail.com',4,'08 street bothell washington',NULL,'172006','+1223344556','+1223344556',NULL,NULL,'2021-01-12 12:26:47',NULL),(19101,20178,'Joseph','David','aalmasch8125@gmail.com',1,'01 west 1st street dallas 88','01 west 1st street dallas 88',NULL,'166778888','166778888',NULL,NULL,'2021-01-12 12:47:02',NULL),(19102,20179,'Anthony','Benjamin','ayaan.jamshaid172@gmail.com',6,'2 west 2nd street plano 22','2 west 2nd street plano 22',NULL,'1998877522','1998877522',NULL,NULL,'2021-01-12 12:47:02',NULL),(20100,21177,'Josea','Jacea','almas.arshad@yahoo.com',2,'Boston',NULL,'1720052','+111111112','+111111112',NULL,NULL,'2021-01-12 14:18:47',NULL),(20101,20181,'Parker','Wesley','almas.arshad172@hotmail.com',5,'2 west street new town arlington','2 west street new town arlington',NULL,'16677881','16677881',NULL,NULL,'2021-01-12 12:47:02',NULL),(20102,21178,'Jose','Jace','almas.arshad@yahoo.com',4,'1 new street bothel','1 new street bothel','17200172','+123456789',NULL,1,NULL,'2021-01-12 18:22:21',1),(20103,21179,'Parker','Wesley','almas.arshad172@hotmail.com',2,'Bothell street no 1','Bothell street no 1',NULL,'198765432','198765432',NULL,NULL,'2021-01-12 18:39:30',NULL),(20104,21180,'Khalid','Aabi','jobs@YAHOO',4,'101 Al Falah Mason','101 Al Falah Mason','12089','973349034',NULL,1,NULL,'2021-01-23 10:23:50',1),(20106,21182,'Devin','Kevin','muhammad.almas172@gmail.com',2,'11 new street Dallas','11 new street Dallas','1720012','1231231231',NULL,1,NULL,'2021-01-23 12:37:10',1),(20107,21183,'Kevin','Robert','muhammad.almas172@gmail.com',2,'11 new street Dallas',NULL,'1722','3042676412','3042676412',NULL,NULL,'2021-01-23 13:07:19',NULL),(20108,21184,'Josh','Caleb','ayaan.jamshaid173@gmail.com',1,'10 second Street Plano',NULL,'1720','3055875124','3055875124',NULL,NULL,'2021-01-23 13:32:18',NULL),(20109,21185,'John','Robert','aalmasch8125@gmail.com',5,'20 third street Arlington','20 third street Arlington',NULL,'3039363172','3039363172',NULL,NULL,'2021-01-23 13:55:59',NULL),(20110,21186,'Asad','Ali','ayaan.jamshaid172@gmail.com',1,'22 Plano 2nd street','22 Plano 2nd street',NULL,'3086578772','3086578772',NULL,NULL,'2021-01-23 18:15:45',NULL);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:28
