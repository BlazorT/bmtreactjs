CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configurations`
--

DROP TABLE IF EXISTS `configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configurations` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `OrganizationId` int NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Description` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Key` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Value` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Status` int NOT NULL,
  `CreatedBy` int DEFAULT NULL,
  `CreatedAt` datetime(3) DEFAULT NULL,
  `LastUpdatedBy` int DEFAULT NULL,
  `LastUpdatedAt` datetime(3) DEFAULT NULL,
  `NetworkId` int NOT NULL,
  `ROWVer` int NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configurations`
--

LOCK TABLES `configurations` WRITE;
/*!40000 ALTER TABLE `configurations` DISABLE KEYS */;
INSERT INTO `configurations` VALUES (1,1,'invitationEmailSubject','invitationEmailSubject','invitationEmailSubject','BMT Support Team',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',1,1),(2,1,'invitationEmailBody','invitationEmailBody','invitationEmailBody','Dear {0}, <br> <br>Congratulations!   Your registration to BMT has been successfully completed.  <br><br> Thank you,<br> <br>NOTE :- PLEASE DO NOT REPLY TO THIS MESSAGE <br><br> BMT admin <br>Ph.1-888-BMT <br> www.4dsps.com',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',1,1),(3,1,'profilePwdResetEmail','profilePwdResetEmail','profilePwdResetEmail','Dear {0}, <br> <br> As per your request, we have sent you the security token <b>{1} </b> to reset your password. <br>  Thank you for using BMT, <br><br>NOTE :- PLEASE DO NOT REPLY TO THIS MESSAGE <br> <br>BMT  Support <br> www.blazortech.com <br> Ph. +1(302)339-2216',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',1,1),(4,1,'smstemplate','smstemplate','smstemplate','HI Guys- Blazor Meia Toolkt is please to contact your for circulating message about rule & regulations, {message} - Looking Forward.. Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',1,1),(5,1,'WhatsApp','WhatsApp','WhatsApp','HI Guys- Blazor Meia Toolkt is please to contact your for circulating message about rule & regulations, {message} - Looking Forward.. Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',2,1),(6,1,'AccountStatusChangedEmailBody','AccountStatusChangedEmailBody','AccountStatusChangedEmailBody','Account Status Changed',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',1,1),(7,1,'instagram','instagram','instagram','Mealz N Dealz - For online food orders, complete Restaurant Management System, Token System <br>  BMT Admin <br> Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',6,1),(8,1,'twitter','twitter','twitter','Mealz N Dealz - For online food orders, complete Restaurant Management System, Token System <br>  BMT Admin <br> Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',4,1),(9,1,'snapchat','snapchat','snapchat','Mealz N Dealz - For online food orders, complete Restaurant Management System, Token System <br>  BMT Admin <br> Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',9,1),(10,1,'tiktok','tiktok','tiktok','Mealz N Dealz - For online food orders, complete Restaurant Management System, Token System <br>  BMT Admin <br> Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',8,1),(11,1,'linkedin','linkedin','linkedin','Mealz N Dealz - For online food orders, complete Restaurant Management System, Token System <br>  BMT Admin <br> Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',7,1),(12,1,'facebook','facebook','facebook','Mealz N Dealz - For online food orders, complete Restaurant Management System, Token System <br>  BMT Admin <br> Blazor Technologies Inc',1,1,'2025-01-01 00:00:00.000',1,'2025-01-01 00:00:00.000',5,1);
/*!40000 ALTER TABLE `configurations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:30
