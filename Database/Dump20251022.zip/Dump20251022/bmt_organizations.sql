CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Address` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Contact` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `WhatsApp` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `strength` int DEFAULT '0',
  `Email` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `IBANOrWireTransferId` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `logoAvatar` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `WebAddress` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Instagram` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `FB` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CurrencyId` int DEFAULT NULL,
  `CityId` int DEFAULT '0',
  `UpdatedBy` int DEFAULT NULL,
  `FMCToken` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ExpiryTime` datetime(3) DEFAULT NULL,
  `LastUpdatedBy` int DEFAULT NULL,
  `LastUpdatedAt` datetime(3) DEFAULT NULL,
  `CreatedBy` int DEFAULT NULL,
  `CreatedAt` datetime(3) NOT NULL,
  `RowVer` int NOT NULL,
  `Status` int DEFAULT '1',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Stores_Contact` (`Contact`,`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=3107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,'6BY7 LLC','','113 # A Link','03055875124','03055875124',0,'madilwaheed456@gmail.com','','productImages/76584be8-f554-4271-832c-b996baa572d8_.jpg',NULL,'50','',2,12029,NULL,NULL,'2025-08-01 21:10:06.000',1,'2025-09-30 13:24:36.239',1,'2025-08-01 21:10:06.000',44,1),(2,'4DSPS LLC','4DSPS LLC','4DSPS LLC','45465454','45465454',NULL,'adilwahed@gmail.com',NULL,'','','60',NULL,1,0,2,NULL,NULL,2,'2023-12-18 07:32:44.848',NULL,'2025-08-01 21:10:06.000',2,1),(3095,'Geraldine Waller LLC','Clarke Williamson','Quo sed consequuntur','023587489','023587489',NULL,'mabod@mailinator.com','Quo sed consequuntur',NULL,'','5',NULL,4,0,14173,NULL,NULL,14173,'2024-01-26 11:06:18.324',14173,'2025-08-01 21:10:06.000',13,1),(3096,'Justin Cyber','cyber llc ','united town crishmA','03337069742','03337069742',NULL,'justincyber172@gmail.com','united town crishmA',NULL,'https://www.4dsps.com','7',NULL,2,0,1,NULL,NULL,1,'2024-01-27 11:55:46.320',14173,'2025-08-01 21:10:06.000',3,1),(3097,'ahmad raza','ahmad&co','blazor.com','987567899','',NULL,'ahmadraza@gmail.com','blazor.com','','blazor.com','6',NULL,1,0,1,NULL,NULL,1,'2024-02-10 13:22:05.447',1,'2025-08-01 21:10:06.000',1,1),(3098,'',NULL,'','',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,14173,NULL,NULL,1,'2025-08-05 11:51:33.106',1,'2025-08-01 21:10:06.000',9,4),(3099,'AD',NULL,'','03487637599','03487637599',4,'madilwaheed456@gmail.com','',NULL,NULL,'','',2,12017,NULL,NULL,NULL,14437,'2025-08-28 12:51:40.805',14437,'2025-08-28 12:51:40.805',1,1),(3100,'DarAlKhair LLC','','Al Marijah Area ZamZam Market (East of Al Marijah Mosque) P.O.Box 71049 Sharjah UAE','+971 6 551 910','+971 50 132 5063',0,'info@blazortech.com','','',NULL,'daralkhairsharjah','DarAlKhairSharjah',10,12017,NULL,NULL,'2025-09-18 08:20:22.194',1,'2025-10-14 11:42:45.883',1,'2025-09-18 08:20:22.194',2,1),(3106,'Alexa Traders',NULL,'','3467637599','',0,'alex@gmail.com','',NULL,NULL,'','',2,12017,NULL,NULL,NULL,1,'2025-10-14 10:51:44.387',1,'2025-10-14 10:51:44.387',1,1);
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:33
