CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `Id` int NOT NULL,
  `Code` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Description` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `SortOrder` int NOT NULL,
  `CountryId` int DEFAULT NULL,
  `Status` int NOT NULL,
  `CreatedBy` int DEFAULT NULL,
  `CreatedAt` datetime(3) NOT NULL,
  `LastUpdatedBy` int DEFAULT NULL,
  `LastUpdatedAt` datetime(3) DEFAULT NULL,
  `RowVer` int NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (3,'Ark','Arkansas','Arkansas',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(4,'Was','Washington, D.C.','Washington, D.C.',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(5,'Del','Delaware','Delaware',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(6,'Flo','Florida','Florida',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(7,'Geo','Georgia','Georgia',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(8,'Kan','Kansas','Kansas',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(9,'Lou','Louisiana','Louisiana',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(10,'Mar','Maryland','Maryland',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(11,'Mis','Missouri','Missouri',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(12,'Mis','Mississippi','Mississippi',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(13,'Nor','North Carolina','North Carolina',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(14,'Okl','Oklahoma','Oklahoma',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(15,'Sou','South Carolina','South Carolina',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(16,'Ten','Tennessee','Tennessee',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(17,'Tex','Texas','Texas',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(18,'Wes','West Virginia','West Virginia',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(19,'Ala','Alabama','Alabama',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(20,'Con','Connecticut','Connecticut',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(21,'Iow','Iowa','Iowa',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(22,'Ill','Illinois','Illinois',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(23,'Ind','Indiana','Indiana',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(24,'Mai','Maine','Maine',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(25,'Mic','Michigan','Michigan',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(26,'Min','Minnesota','Minnesota',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(27,'Neb','Nebraska','Nebraska',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(28,'New','New Hampshire','New Hampshire',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(29,'New','New Jersey','New Jersey',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(30,'New','New York','New York',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(31,'Ohi','Ohio','Ohio',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(32,'Rho','Rhode Island','Rhode Island',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(33,'Ver','Vermont','Vermont',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(34,'Wis','Wisconsin','Wisconsin',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(35,'Cal','California','California',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(36,'Col','Colorado','Colorado',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(37,'New','New Mexico','New Mexico',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(38,'Nev','Nevada','Nevada',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(39,'Uta','Utah','Utah',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(40,'Ari','Arizona','Arizona',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(41,'Ida','Idaho','Idaho',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(42,'Mon','Montana','Montana',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(43,'Nor','North Dakota','North Dakota',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(44,'Ore','Oregon','Oregon',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(45,'Sou','South Dakota','South Dakota',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(46,'Was','Washington','Washington',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(47,'Wyo','Wyoming','Wyoming',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(48,'Haw','Hawaii','Hawaii',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(49,'Ala','Alaska','Alaska',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(50,'Ken','Kentucky','Kentucky',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(51,'Mas','Massachusetts','Massachusetts',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(52,'Pen','Pennsylvania','Pennsylvania',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(53,'Vir','Virginia','Virginia',2,1,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:19:23.200',1),(54,'AB','Alberta','Alberta',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(55,'BC','British Columbia','British Columbia',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(56,'MB','Manitoba','Manitoba',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(57,'NB','New Brunswick','New Brunswick',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(58,'NL','Newfoundland and Labrador','Newfoundland and Labrador',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(59,'NT','Northwest Territories','Northwest Territories',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(60,'NS','Nova Scotia','Nova Scotia',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(61,'NU','Nunavut','Nunavut',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(62,'ON','Ontario','Ontario',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(63,'PE','Prince Edward Island','Prince Edward Island',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(64,'QC','Quebec','Quebec',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(65,'SK','Saskatchewan','Saskatchewan',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1),(66,'YT','Yukon Territory','Yukon Territory',2,2,1,1,'2023-12-11 20:19:23.200',1,'2023-12-11 20:29:18.800',1);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:30
