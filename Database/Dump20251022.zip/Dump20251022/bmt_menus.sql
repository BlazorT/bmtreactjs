CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Description` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ActionName` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Tag` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `title` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `MenueIcon` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ParentID` int DEFAULT NULL,
  `SortOrder` int NOT NULL,
  `IsVisible` tinyint NOT NULL,
  `LastUpdatedBy` int DEFAULT NULL,
  `CreatedBy` int DEFAULT NULL,
  `CreatedAt` datetime(3) DEFAULT NULL,
  `LastUpdatedAt` datetime(3) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `badge` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Dashboard','Dashboard','Dashboard','CNavItem','Dashboard','cilSpeedometer',0,1,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,'{\n      color: \'info\',\n      text: \'NEW\',\n    }'),(2,'Admin','Admin','services','CNavGroup','Admin','cilUser',0,2,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(3,'Organizations','Organizations','Organizations','CNavGroup','Organizations','cilUser',0,3,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(4,'Reports','Reports','Reports','CNavGroup','Reports','cilFile',0,4,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(5,'Pricing','pricing','/pricing','CNavItem','Pricing','cilRuble',2,4,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(6,'Organizations','Organizations','/Organizations','CNavItem','Organizations','cilFile',2,2,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(7,'Users','Users','/Users','CNavItem','Users','cilUser',2,1,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(8,'Packages','Packages','/Packages','CNavItem','Packages','cilRuble',2,3,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(9,'Global Preference','globalpreference','/globalpreference','CNavItem','globalpreference','cilSettings',2,5,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(10,'Organizations Users','organizationsusers','/organizationsusers','CNavItem','organizationsusers','cilUser',3,1,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(11,'Campaigns Listing','campaignslisting','/campaignslisting','CNavItem','campaignslisting','cilUser',3,2,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(12,'Network Setting','networksetting','/networksetting','CNavItem','networksetting','cilUser',3,3,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(13,'Campaign Add','campaignadd','/campaignadd','CNavItem','campaignadd','cilUser',3,4,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(14,'Logs','Logs','/Logs','CNavItem','Logs','cilFile',4,1,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(15,'Audit Logs','AuditLogs','/AuditLogs','CNavItem','AuditLogs','cilFile',4,2,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(16,'Organization Report','organizationreport','/organizationreport','CNavItem','organizationreport','cilFile',4,3,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(17,'User Report','UserReport','/UserReport','CNavItem','UserReport','cilFile',4,4,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(18,'Campaign Stats','Campaign Stats','campaignNotification','CNavItem','Campaign Stats','cilFile',4,5,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(19,'Role Rights','Role Rights','bmtRoles','CNavItem','Role Rights','cilRuble',2,3,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(20,'Recipients','Recipients','recipientsGrid','CNavItem','Recipients','cilFile',2,4,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL),(35,'Global Template','Global Template','globaltemplate','CNavItem','Template','cilFile',2,3,1,1,1,'2023-12-20 00:00:00.000','2023-12-20 00:00:00.000',1,NULL);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:30
