CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `basicconfigurations`
--

DROP TABLE IF EXISTS `basicconfigurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basicconfigurations` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DefaultPublicUserId` int DEFAULT NULL,
  `DefaultOrgId` int DEFAULT NULL,
  `DefaultOrgName` varchar(200) DEFAULT NULL,
  `SmtpServer` varchar(100) NOT NULL,
  `SMTPPort` int DEFAULT NULL,
  `isProxyEnabled` tinyint unsigned DEFAULT '1',
  `SSLEnabled` tinyint unsigned DEFAULT '1',
  `sms_qouta` bigint DEFAULT NULL,
  `proxy_server` varchar(200) DEFAULT NULL,
  `proxy_user_pwd` varchar(200) DEFAULT NULL,
  `proxy_user_name` varchar(200) DEFAULT NULL,
  `admin_email` varchar(200) DEFAULT NULL,
  `sms_service_user` varchar(200) DEFAULT NULL,
  `sms_password` varchar(200) DEFAULT NULL,
  `sms_service_url` varchar(200) DEFAULT NULL,
  `SmtpUser` varchar(200) NOT NULL,
  `SmtpUserPwd` varchar(200) NOT NULL,
  `fcmSenderId` varchar(200) NOT NULL,
  `fcmServerKey` varchar(200) NOT NULL,
  `ApiAuthKey` varchar(200) NOT NULL,
  `InsertSMSHistoryQuery` varchar(500) NOT NULL,
  `email_sender` varchar(500) NOT NULL,
  `GetSMSNotificationsQuery` varchar(500) NOT NULL,
  `LastUpdatedBy` int DEFAULT NULL,
  `CreatedBy` int DEFAULT NULL,
  `CreatedAt` datetime(3) NOT NULL,
  `LastUpdatedAt` datetime(3) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `SmtpSenderEmail` varchar(45) DEFAULT NULL,
  `email_notification_enabled` tinyint DEFAULT '1',
  `sms_notification_enabled` tinyint DEFAULT '1',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `proxy_user_pwd_UNIQUE` (`proxy_user_pwd`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basicconfigurations`
--

LOCK TABLES `basicconfigurations` WRITE;
/*!40000 ALTER TABLE `basicconfigurations` DISABLE KEYS */;
INSERT INTO `basicconfigurations` VALUES (1,1,1,'Blazor Media Toolkit','smtp.ionos.com',587,0,1,0,'','','','admin@blazortech.com','','','','admin@bmt.blazortech.com','Blazor@024()','noreply@blazortech.com','AAAAdkqWTpc:APA91bGlCzCOUaZfigyWGvIONr31Hzu6G9tIPgDP6EZ4kw5f0xfrEqHvZndETrEsiKtwzqjLkkuQA23mYSyu_AKTgBtEhc1gGcBOPi6VNfKjz-pH0LUF0q-RSL0zd7Aowmw3og4bGhUq','cVQ-h9G7QPCs3ErRdmsGNE:APA91bGlsWbE6ouc9jbIskdJOSF0SqwWq-9HXGGeewcs5ESpH-ryhoKYgcYIx19Iay_geMmufvWNb0M6woPo1jYNvIS0tiGZjXluSDuDbLeHyDeHJJ1ZGL_eq06EVb_0AyfsVeCjHND8','NULL','bmt@bmt.blazortech.com','NULL',14173,1,'2023-04-10 00:00:00.000','2024-02-07 08:17:00.000',1,'noreply@blazortech.com',1,1);
/*!40000 ALTER TABLE `basicconfigurations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:35
