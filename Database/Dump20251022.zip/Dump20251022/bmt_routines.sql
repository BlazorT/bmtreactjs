CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'bmt'
--
/*!50003 DROP PROCEDURE IF EXISTS `spAddUpdateRoleRights` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spAddUpdateRoleRights`(p_vrightsjson  JSON)
BEGIN
declare v_lastinserted int default 0;
drop temporary table if exists tmp_RoleRights;
create temporary table tmp_RoleRights (Id int, RoleId int, MenuId int,full int, canAdd int, canUpdate int,canView int,canPrint int, canExport int , canDelete int,createdBy int,rowVer int,lastUpdatedBy int,createdAt datetime,Status int);

-- Insert into temp
 insert into tmp_RoleRights(Id, RoleId, MenuId,full, canAdd, canUpdate,canView,canPrint, canExport, canDelete,createdBy,rowVer,lastUpdatedBy,createdAt,Status) 
select Id, RoleId, MenuId,full, canAdd, canUpdate,canView,canPrint, canExport, canDelete,createdBy,rowVer,lastUpdatedBy,createdAt,Status from    JSON_TABLE(p_vrightsjson, '$[*]' COLUMNS (
                Id int  PATH '$.Id',
                RoleId int  PATH '$.RoleId',
                MenuId int PATH '$.MenuId',
                full int PATH '$.Full',
                canAdd int PATH '$.CanAdd',
                canUpdate int PATH '$.CanUpdate',
                 canView int PATH '$.CanView',
                canPrint int PATH '$.CanPrint',
                canExport int PATH '$.CanExport',
                 canDelete int PATH '$.CanDelete',
                 createdBy int PATH '$.CreatedBy',               
                 lastUpdatedBy int PATH '$.LastUpdatedBy',
                 createdAt datetime PATH '$.CreatedAt',                 
                rowVer int PATH '$.RowVer',
                Status int PATH '$.Status'
                )) as J;
     
     -- Update EoleRights
   UPDATE  roleright rr
	JOIN tmp_RoleRights  rro
	on rr.Id=rro.Id 
     set rr.canAdd = rro.canAdd,rr.canUpdate = rro.canUpdate,rr.full = rro.full, rr.canView = rro.canView, rr.canPrint = rro.canPrint,rr.CanExport = rro.canExport,rr.CanDelete = rro.canDelete,rr.rowVer= rr.rowVer+1, rr.status = rro.status,  rr.LastUpdatedAt= UTC_TIMESTAMP(3), rr.LastUpdatedBy=rro.LastUpdatedBy
	where rro.Id > 0 and  rr.RoleId = rro.RoleId and rr.MenuId = rro.MenuId;
  
SELECT v_lastinserted=ROW_COUNT();
-- New Role Rights

INSERT INTO `roleright`(`RoleId`,`MenuId`,`Full`,`CanAdd`,`CanDelete`,`CanExport`,`CanPrint`,`CanView`,`CanUpdate`,`Status`,`LastUpdatedBy`,`CreatedBy`,`CreatedAt`,`LastUpdatedAt`,`RowVer`)
select  RoleId, MenuId,full, canAdd, CanDelete, CanExport,canPrint, canView, canUpdate,Status,lastUpdatedBy,createdBy,createdAt, UTC_TIMESTAMP(3),ifnull(rowVer,1)
from tmp_RoleRights where id<=0 and NOT EXISTS( Select 'z' from roleright  rr where  rr.RoleId = tmp_RoleRights.RoleId and rr.MenuId = tmp_RoleRights.MenuId);

-- Get Max Id
if(ifnull(v_lastinserted,0)=0) then
select v_lastinserted= Last_insert_id();
END IF;
select v_lastinserted;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAddUpdateUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spAddUpdateUser`(p_id int/* =0 */,p_OrgId int/* =0 */, p_stateId int/* =0 */,p_cityName nvarchar(200)/* ='' */,p_firstname nvarchar(50)/* ='' */,p_IMs nvarchar(100)/* ='' */, p_lastname nvarchar(50)/* ='' */,p_SecurityToken nvarchar(500)/* ='' */,  p_username nvarchar(50),p_email nvarchar(50),p_FMCToken nvarchar(500),p_logoimageName nvarchar(200),p_IMEI nvarchar(200)/* ='' */,p_Password nvarchar(50),  p_roleId int ,p_Contact nvarchar(50)/* ='' */, p_CityId int/* =0 */, p_status int/* =0 */, p_regsource int/* =0 */, p_RegistrationType int/* =0 */)
BEGIN

declare v_UserId int default p_id;
if(p_id > 0) then
Update `users` set Status=p_status ,LastName=(case when char_length(rtrim(p_lastname))<=0 OR p_lastname is null then  lastname else p_lastname end) ,FirstName=(case when char_length(rtrim(p_firstname))<=0 OR p_firstname is null then  FirstName else p_firstname end) ,UserName=(case when char_length(rtrim(p_username))<=0 OR p_username is null then  UserName else p_username end) ,password=(case when char_length(rtrim(p_Password))<=0 OR p_Password is null then  password else p_Password end) ,FMCToken= (case when char_length(rtrim(p_FMCToken))<=0 OR p_FMCToken is null then  FMCToken else p_FMCToken end),Avatar=(case when char_length(rtrim(p_logoimageName))<=0 OR p_logoimageName is null then  Avatar else p_logoimageName end) ,  LastUpdatedAt=UTC_TIMESTAMP(3) where id=p_id;
ELSE

BEGIN

 if ( p_CityId=0 and char_length(rtrim(p_cityName)) > 1)
 THEN
	 if(NOT Exists(select 'x' from cities where `Name` like Concat('%',lower(p_cityName),'%') and StateId=p_stateId))
	 THEN
	 -- SQLINES LICENSE FOR EVALUATION USE ONLY
 	INSERT INTO `cities`(`Name`,`Code`,`Description`,`SortOrder`,`StateId`,`Status`,`CreatedBy`,`CreatedAt`,`LastUpdatedBy`,`LastUpdatedAt`,`RowVer`)
		 VALUES
			   (p_cityName,SUBSTRING(p_cityName, 1, 3),p_cityName ,1,p_stateId,1,v_UserId,UTC_TIMESTAMP(3),v_UserId,UTC_TIMESTAMP(3),1);
			   set p_CityId= LAST_INSERT_ID();
	END IF; 
 END IF;
if(not Exists(Select 'X' from `users` usrs where  Status=1 and (LOWER(usrs.Email)=LOWER(p_email) OR usrs.UserName =p_username) and (p_OrgId=0 or usrs.`OrgId`=p_OrgId) ))
THEN
-- SQLINES LICENSE FOR EVALUATION USE ONLY
INSERT INTO `users`
(`PaymentDetailId`,`OrgId`,`UserCode`,`RegistrationSource`,`FMCToken`,`CityId`,`UserName`,`SecurityToken`,`Contact`,`FirstName`,`MiddleName`,`LastName`,`Nick`,`Email`,`Password`,`RoleID`,`GPSLocation`,`IMs`,`AddressId`,`GenderID`,`Avatar`,`Remarks`,`Title`,`Status`,`BusinessVolume`,`DOB`,`RegistrationTime`,`CreatedBy`,`CreatedAt`,`LastUpdatedBy`,`LastUpdatedAt`,`RowVer`)
--  SQLINES DEMO *** ,[FirstName],UserName,[Email],[Password],StoreID,[RoleID],[Address],[PrimaryContact] ,[IdentityID],[GenderID] ,[Status],[CreatedBy],[CreatedAt] ,[LastUpdatedBy] ,[LastUpdatedAt], CityId,FMCToken,IM,RegistrationSource, Avatar)
VALUES
(p_id,p_OrgId,(case when char_length(rtrim(p_lastname))<=0 OR p_lastname is null then  p_username else p_lastname end),1, p_FMCToken, p_CityId,p_username,ifnull(p_SecurityToken,''),p_Contact, (case when char_length(rtrim(p_firstname))<=0 OR p_firstname is null then  '' else p_firstname end),'', p_lastname,p_lastname, p_email,p_Password,p_roleId,null ,p_IMs,  1,1, p_logoimageName ,null, '111111111111111'  ,p_status,1,UTC_TIMESTAMP(3) ,UTC_TIMESTAMP(3),1,UTC_TIMESTAMP(3), 1,UTC_TIMESTAMP(3),1);
set v_UserId = LAST_INSERT_ID();
ELSE
Select ID Into v_UserId from `users` usrs where (LOWER(usrs.Email)=LOWER(p_email) OR usrs.UserName =p_username) and (p_OrgId=0 or usrs.`OrgId`=p_OrgId and Status=1);
END IF;
-- Log... SQLINES DEMO ***
	if(p_RegistrationType=1 AND Exists(Select 'X' from `onlineusers` where `UserID`= v_UserId))
	THEN
	update  `onlineusers`  set `LoginTime`=UTC_TIMESTAMP(3), Status=1 where  `UserID`=v_UserId;
	ELSEIF (p_RegistrationType=1)
	THEN
	-- SQLINES LICENSE FOR EVALUATION USE ONLY
	INSERT INTO `onlineusers` (`UserID` ,`LoginTime`,`LogoutTime`,`MachineIP`,`Status`)VALUES(v_UserId,UTC_TIMESTAMP(3),null,'0000000000',1);
	end if;
END;
END IF;
Select v_UserId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spCompaignsReportData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spCompaignsReportData`( p_OrgId int/* =0 */,p_Status int/* =0 */, p_DateFrom date, p_DateTo date)
BEGIN


SELECT
ifnull(org.Name,'')  OrgName , Convert(org.CreatedAt, date) CreatedAt ,ifnull(count(cmpgn.id),0) TotalCompaigns,sum(case when ifnull(cmpgn.status,0) =4 then 1 else 0 end) CompletedCompaigns, sum(case when ifnull(cmpgn.status,0)=1 then 1 else 0 end) InprogressCompaigns , timestampadd(month,-12,now(3)) ExpireTime,sum(ifnull(cmpgn.TotalBudget, 0)) budget,   case when org.Status =1 then 'Active' else 'Disabled' end OrgStatus
FROM Organizations org 
left outer join OrgPackageDetail opdtl on org.Id= opdtl.OrgId and opdtl.Status= 1
left outer join Compaigns cmpgn on cmpgn.OrgId= org.Id -- and... SQLINES DEMO ***
where (p_OrgId=0 OR org.id=p_OrgId) and   Convert(org.CreatedAt, date)>= CONVERT(p_DateFrom, date) and  Convert(org.CreatedAt, date) <= CONVERT(p_DateTo, date)
--  SQLINES DEMO *** e when @Status=0 then u.Status else  @Status end) and RoleID=2
group by org.Name  ,org.Status,Convert(org.CreatedAt, date);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDashboardData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spDashboardData`(p_OrgId int/* =0 */)
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.
declare v_Last24Hrs date default Timestampadd(day, -1, now(3));
declare v_LastMonth date default Timestampadd(Month, -1, now(3));
declare v_LastYear date default Timestampadd(Year, -1, now(3));
  Declare v_TotalMonths int;
  DECLARE v_MonthSerial  int;   
  declare v_FormatedDateFrom date;
  Declare v_StartDate date;
  declare v_Month int;
  DECLARE v_previousMonth  float;
DECLARE v_Average   float;
  Declare v_TotalCompaigns int; Declare  v_TotalAmount decimal(38,2); Declare v_MonthAmount decimal(38,2) ; Declare v_GrandFundsAmount decimal(38,2) ; Declare v_GrandPercentage decimal(38,2);
  set v_FormatedDateFrom=CAST(CONCAT(LTRIM(RTRIM(convert(year(convert(now(3), date)), char))),'-',LTRIM(RTRIM(convert(month(now(3)), char))),'-01') as date);
--  SQLINES DEMO *** DateFrom date= CAST(LTRIM(RTRIM(str(datepart(Year,convert(date,@LastYear)))))+'-'+LTRIM(RTRIM(str(datepart(Month,@LastYear))))+'-01' as date)
set v_StartDate=now(3);
set v_Month=1;

--  SQLINES DEMO *** SubscribersSheet as table (TotalOrgs int  , NewOrgs int,   TotalAmount decimal(38,2) ,NewAmount decimal(38,2) ,  StatementHead varchar(100))
drop temporary table if exists tmp_DashboardGridData;
create temporary table tmp_DashboardGridData (TotalCompaigns int  , NewCompaigns int,   FundsAmount decimal(38,2) ,PercentageIncrease decimal(38,2) ,  DataOfMonth varchar(20), MonthNumber int);

SELECT
Count(Distinct cmpdtl.Id ),ifnull(sum(p.TotalChargedAmnt),0) INTO v_TotalCompaigns, v_TotalAmount from Compaigns cmpdtl left outer join Payment p on p.OrgId =cmpdtl.OrgId where cmpdtl.Status=1;

--  SQLINES DEMO *** ar int = datepart(Year,@todayDate)

Select ifnull(min(CreatedAt), now(3)) Into v_StartDate from Users  where status=1 and (p_OrgId=0 OR OrgId=p_OrgId);-- Rol... SQLINES DEMO ***

while v_Month <= 12 and v_FormatedDateFrom  >=  v_StartDate
do
SELECT
ifnull(sum( p.TotalChargedAmnt),0)  , ifnull(sum( ps.TotalChargedAmnt),0) INTO v_TotalAmount, v_MonthAmount
FROM  Payment p
left outer join  Payment ps on p.Id =ps.id and Convert(p.ValueTime, date) >=  v_FormatedDateFrom and Convert(p.ValueTime, date) < timestampadd(month,1,v_FormatedDateFrom) --  SQLINES DEMO *** ormatedDateFrom)  --and u.Status=1
where  Convert(p.ValueTime, date) < timestampadd(month,1,v_FormatedDateFrom)  and p.Status=1;
-- Sub... SQLINES DEMO ***
-- SQLINES LICENSE FOR EVALUATION USE ONLY
INSERT INTO tmp_DashboardGridData(TotalCompaigns,NewCompaigns,FundsAmount,PercentageIncrease,DataOfMonth, MonthNumber)
SELECT
v_TotalCompaigns  , ifnull(Count(cmpns.ID),0)  NewOrgs,   v_MonthAmount TotalAmount , 0,0,v_Month  --  DATE_FORMAT(v_FormatedDateFrom, '%mM', 'en-US') , v_Month
FROM Compaigns cmpns where Convert(cmpns.CreatedAt, date) >=  v_FormatedDateFrom and Convert(cmpns.CreatedAt, date) < timestampadd(month,1,v_FormatedDateFrom)  and  cmpns.Status=1; --  SQLINES DEMO *** 1,2)
Select ifnull(v_TotalCompaigns- ifnull(NewCompaigns,0) ,0) Into v_TotalCompaigns from tmp_DashboardGridData where MonthNumber=v_Month;
set v_Month = v_Month + 1;
set v_FormatedDateFrom =Timestampadd(month, -1,v_FormatedDateFrom);

--  SQLINES DEMO *** eFrom

end while;-- wh... SQLINES DEMO ***
Select  count(TotalCompaigns) Into v_TotalMonths from tmp_DashboardGridData;
select (sum(FundsAmount)*100/v_TotalMonths)  ,ifnull(sum(FundsAmount),0) into v_GrandPercentage, v_GrandFundsAmount  from tmp_DashboardGridData;


set v_previousMonth   = 0.0;
set v_Average   = 0.0;
SET v_MonthSerial = v_TotalMonths;

WHILE v_MonthSerial > 0 -- Co... SQLINES DEMO ***
DO
SELECT  case when v_previousMonth<=0 and FundsAmount <=0 then 0 when v_previousMonth<=0 and FundsAmount > 0 then 100 else ((FundsAmount-v_previousMonth)/v_previousMonth)*100 end, FundsAmount INTO v_Average, v_previousMonth
FROM tmp_DashboardGridData
WHERE MonthNumber=v_MonthSerial;
update tmp_DashboardGridData set  PercentageIncrease =v_Average  WHERE MonthNumber=v_MonthSerial;

SET v_MonthSerial = v_MonthSerial - 1; -- Co... SQLINES DEMO ***
END WHILE;
--  SQLINES DEMO *** ridData set  PercentageIncrease = case when FundsAmount = 0 then 0 else isnull((FundsAmount*100/@GrandPercentage),0)- isnull(@GrandPercentage,0) end
--  SQLINES DEMO *** ridData set  PercentageIncrease = case when NewPlans = 0 OR TotalPlans=0 then 0 else isnull((NewPlans*100)/TotalPlans,0) end
--  SQLINES DEMO *** oardGridData (TotalPlans,NewPlans,FundsAmount, PercentageIncrease, DataOfMonth, MonthNumber) values(70,20,200,50,'Aug',4)
select TotalCompaigns  , NewCompaigns  ,   FundsAmount  AS FundsAmount  , PercentageIncrease  ,  DataOfMonth , MonthNumber from tmp_DashboardGridData   order by MonthNumber;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spForgotPassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spForgotPassword`(p_orgId int, p_email nvarchar(100), p_securitytoken varchar(8), p_pwd varchar(20))
BEGIN
	-- SQLINES DEMO *** ded to prevent extra result sets from
	Declare v_return int Default 0;
	if(char_length(rtrim(ifnull(p_pwd,'')))<=0 and exists ( Select 'X' from users where email=p_email /* and OrgId=@orgId*/))
	THEN
	-- pri... SQLINES DEMO ***
		update users set SecurityToken=p_securitytoken , lastUpdatedAt=now(3), Status=0 where email=p_email /* and OrgId=@orgId*/;
		set v_return= FOUND_ROWS();
		END IF;
if(Exists(Select 'X' from users where Email=p_email  and char_length(rtrim(ifnull(p_pwd,'')))> 2 and SecurityToken= p_securitytoken))
THEN
	update users set SecurityToken=p_securitytoken , status= 1 ,LastUpdatedAt=now(3), Password=p_pwd where Email=p_email and SecurityToken= p_securitytoken;
	-- and... SQLINES DEMO ***
		set v_return= FOUND_ROWS();
END IF;
select v_return;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetAuditLogData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetAuditLogData`(p_OrgId int/* =0 */ ,p_entityid int/* =0 */,  p_keyword varchar(100)/* ='' */, p_datefrom date/* = getutcdate */, p_dateto date/* = getutcdate */)
BEGIN
SELECT
  al.id, al.AuditEntityId ,al.keyValue,al.OldValue, al.NewValue,al.AttributeName, ur.firstname, ur.MiddleName,ur.LastName,    al.CreatedAt, al.CreatedBy , ae.Name EntityName
FROM auditlog al
left outer join  users ur on ur.id= al.CreatedBy
left outer join  auditentities ae on ae.AuditEntityId = al.AuditEntityId
 where (p_entityid=0 OR p_entityid= al.auditEntityId) and (p_OrgId=0 OR p_OrgId= al.OrgId) 
 and (al.OldValue like concat('%',p_keyword ,'%') OR al.NewValue like concat('%',p_keyword ,'%') OR  al.AttributeName like concat('%',p_keyword ,'%') OR al.keyValue like concat('%',p_keyword ,'%'))
and al.createdAt >= p_datefrom and al.createdAt <= p_dateto ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetBMTNotification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spGetBMTNotification`(p_datefrom date/* = getutcdate */)
BEGIN
SELECT
  n.id, ifnull(n.organizationId, 0) organizationId, title, subject, TIMESTAMPDIFF(MINUTE,expirytime, CURRENT_TIMESTAMP()) ExpiryInMinutes  , concat(u.FirstName, '' , u.LastName) sender
  , n.CreatedBy, n.SendFrom, Recipient
FROM notification n
left outer join users u on u.id= n.SendFrom
where  n.CreatedAt >= p_datefrom  and n.Status=1 and TIMESTAMPDIFF(MINUTE,expirytime, CURRENT_TIMESTAMP()) > 0; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetBMTUsersList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spGetBMTUsersList`(p_keyword varchar(100), p_UserId int/* =0 */,p_OrgId int/* =0 */, p_RoleId int/* =0 */, p_status int/* =0 */, p_DateFrom Date , p_DateTo Date)
BEGIN

Select * from (
SELECT usr.id  ,ifnull(usr.OrgId ,0) OrgId , usr.RoleID ,usr.UserName, usrr.Name RoleName,usr.FirstName, usr.MiddleName, usr.LastName, (YEAR(now(3))- ifnull(usr.DOB, NOW(3)))  Age,
CONCAT(usr.FirstName ,' ', ifnull(usr.MiddleName,'') ,' ', usr.LastName)  CompleteName,sts.Name StateName,cty.Name CityName, avatar , ifnull(usr.GenderID,0) GenderID,ifnull(adr.id,0) AddressId,ifnull(adr.Address1,'xxx') Address1  ,ifnull(usr.DOB, RegistrationTime) DOB,   ifnull(adr.CityId,0) CityId, ifnull(cty.StateId,0) StateId, adr.PhoneNumber , adr.ZipPostalCode, adr.FaxNumber
,org.Name  OrgName, ifnull(usr.CityId,0) AddCity
,usr.Email , usr.Password
,usr.`CreatedBy`,usr.Contact
,usr.`CreatedAt`,'' Title, ifnull(video.id,0) IntroVideoReferenceId,video.AvailabilityURL IntroVideoURL, video.FileUniqueId, ifnull(video.Status,0) ApprovalStatus, ifnull(video.Remarks,'') ApprovalRemarks
,ifnull(usr.`LastUpdatedBy`,0)`LastUpdatedBy`
,usr.`LastUpdatedAt`
,usr.`Status`
,usr.`RowVer`
FROM `Users` usr
left outer join Address adr on adr.UserId =usr.id
left outer join UserRoles usrr on usrr.ID =usr.RoleID
left outer join Organizations org on usr.OrgId =org.Id
left outer join MediaSourceInfo video on video.UserId =usr.Id -- and... SQLINES DEMO ***
left outer join Cities cty on cty.Id =adr.CityId
left outer join States sts on sts.Id =cty.StateId
where  usr.RoleID in ( 2,5,6) and (usr.RoleID =p_RoleId OR p_RoleId =0) and (usr.Status =p_status OR p_status =0) and usr.Status in ( 1,2)
and Convert(usr.CreatedAt, date) >= p_DateFrom and Convert(usr.CreatedAt, date) <= p_DateTo
and (p_OrgId =0 OR p_OrgId=usr.OrgId) and  (p_UserId =0 OR usr.ID=p_UserId)

) temp where (ifnull(temp.CompleteName,'') like Concat('%',p_keyword,'%') OR  ifnull(temp.Contact,'') like Concat('%',p_keyword,'%') OR  ifnull(temp.email,'') like Concat('%',p_keyword,'%'));


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetBundlingDetailList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetBundlingDetailList`(p_orgid int/* =0 */,p_networkId int/* =0 */)
BEGIN


SELECT bndl.Id,ifnull(FinishTime,bndl.lastupdatedat) FinishTime, HashTags, APIKeySecret, ifnull(bndl.AutoReplyAllowed,0) AutoReplyAllowed,  ifnull(VirtualAccount,0) VirtualAccount,  ifnull(bndl.LastUpdatedAt, bndl.CreatedAt) LastUpdatedAt, bndl.NetworkId, bndl.StartTime,  ifnull(bndl.UnitId,0) UnitId 
,ntwrks.Name networkName,unts.Name unitName, UsedQuota,PurchasedQouta 
,bndl.`Status`
FROM `orgpackagedetail` bndl
left outer join networks ntwrks on ntwrks.id=bndl.NetworkId
left outer join tradeunits unts on unts.id=bndl.UnitId
where (bndl.NetworkId= p_networkId OR p_networkId=0) OR (bndl.OrgId= p_orgid OR p_orgid=0)  ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetDispatchmentDataUpdated` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetDispatchmentDataUpdated`(p_Id bigint/* =0 */ ,p_dspid int/* =0 */ ,p_assignedto int/* =0 */ , p_isAssigned int/* =0 */ , p_assignmentTypeId int/* =0 */ )
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.

SELECT
  d.id, d.DspId ,  ifnull(d.vehicleId,0) vehicleId ,stock.ProductDetailID, 
  p.Name itemname , p.shortcode,  ifnull(d.createdby,0) assignedBy, ifnull(d.AssignedTo,0) AssignedTo, 
  ifnull(d.productDetailId,0) productDetailId, d.LastUpdatedAt, d.LastUpdatedBy,'' inventoryOf, ifnull(stock.TotalAvailableStock,0) AvailableStock, 
  p.BusinessEntityId, ifnull(d.AssignedQty,0) AssignedQty, d.remarks , d.CreatedAt , d.LastUpdatedAt
  , d.LastUpdatedBy  , d.lastUpdatedBy,   ifnull(d.RowVer,0) RowVer, ifnull(d.status,0) status
FROM dispatchment d
left outer join  products p  on p.id= d.ProductDetailId
left outer join  dspstockstats stock  on stock.ProductDetailId= d.ProductDetailId
where (p_Id=0 OR p_Id= v.Id) and (p_DspId=0 OR p_DspId= d.DSPId) and (p_assignedto=0 OR p_assignedto = d.AssignedTo) and (p_isAssigned=0 OR p_isAssigned = d.AssignedTo)  ; -- and... SQLINES DEMO ***

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetDMTNotification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spGetDMTNotification`(p_datefrom date/* = getutcdate */)
BEGIN
SELECT
  n.id, ifnull(n.organizationId, 0) organizationId, title, subject, ifnull(expirytime, CURRENT_TIMESTAMP()) expirytime  , concat(u.FirstName, '' , u.LastName) sender
  , n.CreatedBy, n.SendFrom
FROM notification n
left outer join users u on u.id= n.SendFrom
where  n.CreatedAt >= p_datefrom  and n.Status=1 and TIMESTAMPDIFF(MINUTE,expirytime, CURRENT_TIMESTAMP()) > 0; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetMenuesByRoleId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetMenuesByRoleId`( p_Roleid int)
begin  
/*
Select  sub.ID, ifnull(m.Id,0) MenuID,ifnull(m.Id,sub.ParentID) ParentId,sub.Name MenuName ,sub.Description , sub.MenueIcon as MenueIcon,sub.Id SubMenuId, ifnull(m.Name, sub.Name) as ModuleName ,sub.ActionName ,sub.IsVisible ,ifnull(sub.badge,'') badge, sub.tag, ifnull(rm.id,0) assignmentId ,-- ifnull( sub.ParentID,0) assignmentId,
 ifnull(m.SortOrder,0) ParentMSortOrder,
 sub.Status , Case when rm.Status is null or rm.Status<> 1 then 0 else 1 end RoleMenuStatus , 1 as 'full', sub.title componentname,
 ifnull(rm.RoleID,p_Roleid) RoleID ,ifnull(rm.CanDelete,0) CanDelete, 1 CanAdd ,1 CanExport,1 CanPrint,ifnull(rm.CanUpdate,0) CanUpdate,
 ifnull(rm.CanView,1) CanView, ifnull(m.sortOrder,0) ModuleSortOrder ,sub.sortOrder  MenuSortOrder, ifnull(sub.SortOrder,0) SortOrder
from menus sub
left outer join (Select * from menus ParentMenus where ifnull(ParentMenus.ParentID ,0)=0) as m
on sub.ParentID= m.Id --  SQLINES DEMO *** s null
left outer join  rolemenu rm  on
 rm.MenuID=sub.ID   and (rm.RoleID=p_Roleid)  
 where sub.ActionName is not null and sub.Status=1  -- and m.Id is not null
 order by m.Name  ,sub.Name;
 */
 Select  sub.ID, ifnull(m.Id,0) MenuID,ifnull(m.Id,sub.ParentID) ParentId,sub.Name MenuName ,sub.Description , sub.MenueIcon as MenueIcon,sub.Id SubMenuId, ifnull(m.Name, sub.Name) as ModuleName ,sub.ActionName ,sub.IsVisible ,ifnull(sub.badge,'') badge, sub.tag, ifnull(rts.id,0) assignmentId ,-- ifnull( sub.ParentID,0) assignmentId,
 ifnull(m.SortOrder,0) ParentMSortOrder,
 sub.Status , Case when rts.Status is null or rts.Status<> 1 then 0 else 1 end RoleMenuStatus , 1 as 'full', sub.title componentname,
 ifnull(rts.RoleID,p_Roleid) RoleID ,ifnull(rts.CanDelete,0) CanDelete, 1 CanAdd ,1 CanExport,1 CanPrint,ifnull(rts.CanUpdate,0) CanUpdate,
 ifnull(rts.CanView,1) CanView, ifnull(m.sortOrder,0) ModuleSortOrder ,sub.sortOrder  MenuSortOrder, ifnull(sub.SortOrder,0) SortOrder
from menus sub
left outer join (Select * from menus ParentMenus where ifnull(ParentMenus.ParentID ,0)=0) as m
on sub.ParentID= m.Id --  SQLINES DEMO *** s null
left outer join  roleright rts  on
 rts.MenuID=sub.ID   and (rts.RoleID=p_Roleid)  
 where sub.ActionName is not null and sub.Status=1  -- and m.Id is not null
 order by m.Name  ,sub.Name;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetOrganizationBundlingDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetOrganizationBundlingDetails`(p_OrganizationId int/* =0 */)
BEGIN
SELECT distinct orgP.Id, orgP.`Name` ,orgP.NetworkId, orgP.BusinessId,ifnull(orgP.PostTypeId,0) PostTypeId , ifnull(orgP.UnitId,0) UnitId ,VirtualAccount,ifnull((bpkg.UnitPrice + ifnull(Tax,0)),0) UnitPriceInclTax,  ifnull(orgP.BufferQuota,0) BufferQuota,ifnull(orgP.PurchasedQouta,0) PurchasedQouta,ifnull(orgP.UsedQuota,0) UsedQuota, ifnull(orgP.FinishTime, timestampadd(day,1,UTC_TIMESTAMP(3))) FinishTime,orgP.OrgId, orgP.APIKey,orgP.APIKeySecret, orgP.APIURI, ifnull(orgP.AutoReplyAllowed,0) AutoReplyAllowed , ifnull(orgP.Status,0) Status
,ntwk.CategoryId, ntwk.Name networkName, ntwk.Description networkDesc 
FROM orgpackagedetail orgP 
left outer join organizations orgs on orgP.OrgId = orgs.id and orgs.Status=1
left outer join networks ntwk on ntwk.Id = orgP.NetworkId and ntwk.Status=1
left outer join bundlingpackagedetails bpkg on bpkg.NetworkId = orgP.NetworkId --  SQLINES DEMO *** gP.UnitId 
and orgs.Status=1
left outer join currencies curr on curr.id =orgs.CurrencyId
where  (orgs.Id =p_OrganizationId OR p_OrganizationId =0) and orgP.`Name`  is not null;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetOrganizations` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetOrganizations`(p_OrganizationId int/* =0 */, p_NetworkId int/* =0 */,p_RegistrationDate date/* = null */,p_Status int/* =1 */,p_cityId int/* =1 */,p_keyword varchar(20)/* ='' */)
BEGIN
set  p_RegistrationDate = case when p_RegistrationDate= null then timestampadd(year, -5, now(3)) else p_RegistrationDate end;
SELECT orgs.Id, orgs.`Name` ,orgs.`Description` ,ifnull(orgs.strength,0) strength ,orgs.Contact,ifnull(orgs.ExpiryTime,orgs.CreatedAt)  ExpiryTime, ifnull(orgs.CurrencyId,0) CurrencyId, curr.`name` currencyName, ifnull(orgs.CityId,0) CityId, Instagram,WhatsApp,FB,IBANOrWireTransferId
,ifnull(orgs.`CreatedBy`,0) CreatedBy, ifnull(COUNT(Distinct cmpgns.Id),0) CompaignsCount, concat(ifnull(usrs.FirstName,'') , ' ' , ifnull(usrs.LastName,'')) userName
,orgs.`LastUpdatedAt`, cti.`Name` CityName,orgs.Address, orgs.Email , ifnull(orgs.CreatedAt, now(3)) CreatedAt
,ifnull(orgs.`Status`,1) as Status, ifnull(cti.StateId,0) StateId, orgs.logoAvatar , ifnull(cntry.id,0) countryid, cntry.code
FROM organizations orgs 
left outer join compaigns cmpgns on cmpgns.OrgId =orgs.Id
left outer join users usrs on usrs.ID =orgs.LastUpdatedBy
left outer join cities cti on cti.ID =orgs.CityId
left outer join states stats on stats.id =cti.stateid
left outer join countries cntry on cntry.id = stats.countryid
left outer join currencies curr on curr.id	= orgs.CurrencyId
 where  (orgs.Id =p_OrganizationId OR p_OrganizationId =0) and (p_Status=0 OR orgs.Status =p_Status)
  and (p_NetworkId =0 or exists (Select opdkdt.id from orgpackagedetail opdkdt where opdkdt.NetworkId=p_NetworkId and opdkdt.OrgId=orgs.Id))
 and orgs.CreatedAt >= p_RegistrationDate  and ( orgs.CityId = p_cityId OR ifnull(p_cityId,0)=0) and  (orgs.Name  like  CONCAT('%', p_keyword, '%')   OR orgs.Contact like CONCAT('%', p_keyword, '%')  OR orgs.Email like CONCAT('%', p_keyword, '%') )
group by countryid, cntry.code, orgs.`Name` ,orgs.`Description` ,orgs.strength,orgs.Contact,orgs.ExpiryTime, orgs.CurrencyId, curr.`name` ,
orgs.Id, orgs.`CreatedBy`, orgs.`LastUpdatedAt`,orgs.`Status`, FirstName,LastName,cti.`Name`,orgs.CityId, Instagram,WhatsApp,FB,IBANOrWireTransferId,orgs.Address, orgs.Email,cti.StateId;


/*
SELECT orgs.Id, orgs.`Name` ,orgs.`Description` ,ifnull(orgs.strength,0) strength ,orgs.Contact,ifnull(orgs.ExpiryTime,orgs.CreatedAt)  ExpiryTime, ifnull(orgs.CurrencyId,0) CurrencyId, curr.`name` currencyName, ifnull(orgs.CityId,0) CityId, Instagram,WhatsApp,FB,IBANOrWireTransferId
,ifnull(orgs.`CreatedBy`,0) CreatedBy, ifnull(COUNT(Distinct cmpgns.Id),0) CompaignsCount, concat(ifnull(usrs.FirstName,'') , ' ' , ifnull(usrs.LastName,'')) userName
,orgs.`LastUpdatedAt`, cti.`Name` CityName,orgs.Address, orgs.Email , ifnull(orgs.CreatedAt, now(3)) CreatedAt
,ifnull(orgs.`Status`,1) as Status, ifnull(cti.StateId,0) StateId
FROM Organizations orgs 
left outer join compaigns cmpgns on cmpgns.OrgId =orgs.Id
left outer join Users usrs on usrs.ID =orgs.LastUpdatedBy
left outer join Cities cti on cti.ID =orgs.CityId
left outer join currencies curr on curr.id	 =orgs.CurrencyId
where  (orgs.Id =p_OrganizationId OR p_OrganizationId =0) and (p_Status=0 OR orgs.Status =p_Status)
and (p_NetworkId =0 or exists (Select opdkdt.id from OrgPackageDetail  opdkdt where opdkdt.NetworkId=p_NetworkId and opdkdt.OrgId=orgs.Id))
and orgs.CreatedAt >= p_RegistrationDate
group by orgs.`Name` ,orgs.`Description` ,orgs.strength,orgs.Contact,orgs.ExpiryTime, orgs.CurrencyId, curr.`name` ,
orgs.Id, orgs.`CreatedBy`, orgs.`LastUpdatedAt`,orgs.`Status`, FirstName,LastName,cti.`Name`,orgs.CityId, Instagram,WhatsApp,FB,IBANOrWireTransferId,orgs.Address, orgs.Email,cti.StateId;
*/

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetOrganizationUsersListReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetOrganizationUsersListReport`(p_orgid int/* =0 */ ,p_status int/* =0 */ ,p_keyword varchar(100)/* ='' */ , p_datefrom datetime/* =now(3) */ , p_dateto datetime/* =now(3) */ )
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.
SELECT
  org.id, org.Email, concat(org.Name, '', org.Description) Name,  org.Contact, org.logoavatar, ifnull(org.CityId,0) CityId, ifnull(org.strength,0) strength, s.Name StateName ,c.Name CityName, '' PackageName, ifnull(org.createdAt, now(3)) createdAt ,ifnull(org.createdAt, now(3)) ExpiryTime , ifnull(org.createdBy,0) createdBy, ifnull(org.RowVer,0) RowVer , ifnull(org.status,0) status
FROM organizations org 
left outer join  Cities c on c.id= org.CityId
left outer join  states s on s.id= c.stateid
where (p_orgid=0 OR p_orgid= org.Id) and  (p_status=0 OR p_status =org.status)
and (org.Name like concat('%',p_keyword ,'%') OR org.Email like concat('%',p_keyword ,'%') OR org.Description like concat('%',p_keyword ,'%') OR org.Contact like concat('%',p_keyword ,'%'))
and  org.createdAt >= p_datefrom and org.createdAt <= p_dateto; -- and... SQLINES DEMO ***

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetOrgBundlingDetailList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetOrgBundlingDetailList`(p_orgid int/* =0 */,p_networkId int/* =0 */)
BEGIN

SELECT bndl.Id,ifnull(FinishTime,bndl.lastupdatedat) FinishTime, HashTags, APIKeySecret, ifnull(bndl.AutoReplyAllowed,0) AutoReplyAllowed,  ifnull(VirtualAccount,0) VirtualAccount,  ifnull(bndl.LastUpdatedAt, bndl.CreatedAt) LastUpdatedAt, bndl.NetworkId, ifnull(bndl.StartTime,bndl.CreatedAt) StartTime,  ifnull(bndl.UnitId,0) UnitId 
,ntwrks.Name networkName,unts.Name unitName, ifnull(UsedQuota,0.0) UsedQuota ,ifnull(PurchasedQouta,0.0) PurchasedQouta
,bndl.`Status`
FROM `orgpackagedetail` bndl
left outer join networks ntwrks on ntwrks.id=bndl.NetworkId
left outer join tradeunits unts on unts.id=bndl.UnitId
where (bndl.NetworkId= p_networkId OR p_networkId=0) OR (bndl.OrgId= p_orgid OR p_orgid=0)  ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetOrgBundlingNetworks` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetOrgBundlingNetworks`(p_orgid int/* =0 */,p_networkId int/* =0 */)
BEGIN
/*
SELECT 0 Id, bndl.NetworkId,  ifnull(bndl.UnitId,0) UnitId 
,ntwrks.Name networkName,unts.Name unitName, ifnull(UsedQuota,0.0) UsedQuota ,ifnull(PurchasedQouta,0.0) PurchasedQouta
,bndl.`Status`
FROM `orgpackagedetail` bndl
left outer join networks ntwrks on ntwrks.id=bndl.NetworkId
left outer join tradeunits unts on unts.id=bndl.UnitId
where (bndl.NetworkId= p_networkId OR p_networkId=0) OR (bndl.OrgId= p_orgid OR p_orgid=0)  ;
*/
SELECT   bndl.NetworkId, ntwrks.Name networkName
,bndl.`Status`
, SUM(ifnull(UsedQuota, 0.0))AS UsedQuota  
,SUM(ifnull(PurchasedQouta, 0.0)) AS purchasedQouta, 12.0 unitprice, max(bndl.StartTime) StartTime, max(bndl.FinishTime) FinishTime, 0.0 discount, 0 FreeAllowed
FROM `orgpackagedetail` bndl
left outer join networks ntwrks on ntwrks.id=bndl.NetworkId
left outer join tradeunits unts on unts.id=bndl.UnitId
where (bndl.NetworkId= p_networkId OR p_networkId=0) OR (bndl.OrgId= p_orgid OR p_orgid=0)  and bndl.Status=1
group by  NetworkId, networkName,bndl.`Status`;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetOrgUsers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spGetOrgUsers`(p_orgId int /* =0 */, p_email varchar(100)/* ='' */,p_username varchar(100)/* ='' */,  p_password varchar(200))
BEGIN

-- SQLINES DEMO ***  stop access, isnull(ouin.Status,0) AlreadyLoginStatus

SELECT  u.Id, u.orgid,roleid,username, u.email loginname , lastname ,firstname,ifnull(scti.Name ,'') city ,u.email,`password`,Whatsapp,'' imei, ifnull(u.avatar,ifnull(org.logoAvatar,(Select ProfileImage from NoImage
Limit 1))) avatar, org.Name orgname 
,org.Name orgname,u.Status,0 SubscriptionPackageId, ifnull(u.IMs,'') IM, u.AddressId, '' Address
FROM users u left outer join onlineusers ouin on ouin.UserId=u.ID
left outer join userroles urole on urole.ID=u.RoleID
left outer join organizations org on org.ID=u.OrgId
left outer join cities scti on scti.ID=org.CityId
left outer join states ssts on ssts.ID=scti.StateId
where --  SQLINES DEMO *** d=u.OrgId) and 
(LOWER(u.Email)=LOWER(p_email) OR p_email='' ) AND (LOWER(u.UserName)=LOWER(p_username) OR p_username='' ) and u.Status=1 and (p_password='' OR  u.Password =p_password);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetPricingGlobalList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spGetPricingGlobalList`(p_networkId int/* =0 */)
BEGIN


SELECT bndl.Id,bndl.ApprovalTime, ifnull(bndl.BundlingAllowed,0) BundlingAllowed,  ifnull(bndl.CurrentApplied,0) CurrentApplied , ifnull(bndl.Discount,0) Discount, bndl.FinishTime,bndl.FreeAllowed, ifnull(bndl.LastUpdatedAt, bndl.CreatedAt) LastUpdatedAt, bndl.NetworkId, bndl.StartTime, ifnull(bndl.Tax,0) Tax, ifnull(bndl.UnitId,0) UnitId ,ifnull(bndl.UnitPrice,0) UnitPrice
,ntwrks.Name networkName,unts.Name unitName
,bndl.`Status`
FROM `bundlingpackagedetails` bndl
left outer join networks ntwrks on ntwrks.id=bndl.NetworkId
left outer join tradeunits unts on unts.id=bndl.UnitId
where (NetworkId= p_networkId OR p_networkId=0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGetShowRoomVehicles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetShowRoomVehicles`(p_dspId int/* =0 */ , p_filtersJSON varchar(3000) /* =''*/ )
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.

SELECT
  v.id, ifnull(v.status,0) status, ifnull(v.categoryId,0) categoryId, ODO, MakeDetailId
FROM vehicles v
where (p_dspId=0 OR p_dspId= v.DSPId) and  u.Status=1; -- and... SQLINES DEMO ***

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spGlobalLookUpData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGlobalLookUpData`()
BEGIN
Select * from (
SELECT  Id
,`Name`
, statusCategoryId Code
,`Description` `Desc` ,1 LVType,  SortOrder
FROM `statuses`  where  statusCategoryId=1  -- and Status=1 --  Business Plan Status
UNION ALL
SELECT  Id
,`Name`
, statusCategoryId Code
,`Description` `Desc` ,2 LVType,  SortOrder
FROM `statuses`  where  statusCategoryId=2 -- Delivery Status
UNION ALL
SELECT  Id
,`Name`
, Name Code
, Description  `Desc`, 3 LVType, 1 SortOrder
FROM states where `Status`=1
UNION ALL
SELECT  Id
,`Name`
,`Name` Code
,ifnull(posttypejson,'') `Desc` , 4 LVType, 1 SortOrder
FROM `networks` where `Status`=1
UNION ALL
SELECT  Id
,`Name`
,`Name` Code
,`Description` `Desc` , 5 LVType, 1 SortOrder
FROM `intervaltypes` where `Status`=1
UNION ALL
SELECT  Id
,`Name`
,Color Code
,Description `Desc` , 6 LVType, 1 SortOrder
FROM notificationtypes 
UNION ALL
SELECT  Id
,`Name`
,`Name` Code
,`Description` `Desc` , 7 LVType, 1 SortOrder
FROM packages where `Status`=1
UNION ALL
SELECT  Id
,`Name`
, Code
,`Description` `Desc` , 8 LVType,  SortOrder
FROM `currencies` where  status=1  -- Currecnies

UNION ALL
SELECT  Id
,`Name`
, Code
, Description  `Desc`, 9 LVType, 1 SortOrder
FROM countries where `Status`=1
UNION ALL
SELECT  Id
,`Name`
, Name Code
, Description  `Desc`, 10 LVType, 1 SortOrder
FROM posttypes where `Status`=1
 -- whe... SQLINES DEMO ***

UNION ALL
SELECT  Id
,`Name`
,`Name` Code
,`Description` `Desc` , 22 LVType, 1 SortOrder
FROM userroles
UNION ALL
SELECT  Id
,`Name`
,`ShortCode` Code
,`WeightQty` `Desc` , 23 LVType, 1 SortOrder
FROM tradeunits where Status=1
)temp order by temp.SortOrder;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spLoadConfigurationsList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spLoadConfigurationsList`(p_orgId int/* =0 */ )
BEGIN

SELECT `Id`
,`Name`
,`Description`
,`Key`
,`Value`  ,`status`
,`RowVer`
FROM `configurations` where OrganizationId=p_orgId and status=1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SpMaintainCompaignContacts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `SpMaintainCompaignContacts`( 
	p_json JSON)
BEGIN
	-- SQLINES DEMO *** ded to prevent extra result sets from
	-- SQLINES DEMO *** SELECT statements.
    -- SQLINES DEMO ***  for procedure here
-- SQLINES DEMO ***  char(max)= N'[{"Id":0,"NetworkId":1,"ContentId":["03013007432","123-456-7890","987-654-3210","20-7946-0958","2-9374-4000","98765-43210"],"Desc":"","CreatedBy":1,"CreatedAt":"2025-04-19T08:08:16.501Z","LastUpdatedAt":"2025-04-19T08:08:16.501Z","RowVer":1},{"Id":0,"NetworkId":3,"ContentId":["john.doe@example.com","jane.smith@example.com","alice.johnson@example.com","bob.brown@example.com","eve.davis@example.com"],"Desc":"","CreatedBy":1,"CreatedAt":"2025-04-19T08:08:16.501Z","LastUpdatedAt":"2025-04-19T08:08:16.501Z","RowVer":1}]'
-- drop temporary table if exists then tmp_contacts end if;;
SET @v_RandomNumber = FLOOR(RAND() * 1000) + 10000;
-- SET V_RandomNumber = FLOOR(RAND() * 1000) + 10000;
DROP TABLE IF EXISTS tmp_contacts;
  
create temporary table tmp_contacts (Id int,NetworkId int,OrgId INT,CreatedBy int,contentId nvarchar(500));
-- SQLINES DEMO *** ble table
insert into tmp_contacts(Id,NetworkId,OrgId,CreatedBy,contentId)
SELECT 
    IFNULL(t.Id, 0) AS Id,
    t.NetworkId,
    t.OrgId,
    t.CreatedBy,
    IFNULL(c.ContentItem, '') AS ContentId
FROM JSON_TABLE(
    p_json, '$[*]'
    COLUMNS (
        Id BIGINT PATH '$.id',
        NetworkId INT PATH '$.networkId',
        OrgId INT PATH '$.orgId',
        CreatedBy INT PATH '$.createdBy',
        Content JSON PATH '$.contentlst'  
    )
) AS t
JOIN JSON_TABLE(
    t.Content, '$[*]'
    COLUMNS (
        ContentItem VARCHAR(100) PATH '$'
    )
) AS c;
/*
Select s.id, networkId,OrgId,createdBy,contentId
FROM JSON_TABLE (p_json, '$[*]' columns (id bigint , networkId; int, OrgId int,createdBy int,contentId  AS JSON) as s
CROSS APPLY
     OPENJSON(s.contentId) as 
     */
-- select * from tmp_contacts;
-- select @v_RandomNumber;
if(EXISTS(SELECT 'X' FROM tmp_contacts)) 
THEN

	INSERT INTO `compaignrecipients`(`networkId`,`ContentId`,`SourceId`,`Desc`,`OrgId`,`CreatedBy`,`CreatedAt`,`LastUpdatedBy`,`LastUpdatedAt`,`RowVer`,`Status`)
	select NetworkId,contentId,1, 'json' ,OrgId,CreatedBy,UTC_TIMESTAMP(3),CreatedBy,UTC_TIMESTAMP(3),@v_RandomNumber,1 from tmp_contacts c where id<= 0 and length(c.contentId) >0
	and NOT Exists (Select 'X' from compaignrecipients sc where sc.OrgId=c.OrgId and sc.ContentId  =c.ContentId and sc.networkId=c.networkId);

 END IF;
 
 select c.NetworkId,c.contentId,n.Name from tmp_contacts c 
inner join compaignrecipients sc on sc.orgid=c.orgid and sc.ContentId  = c.ContentId   and sc.networkId=c.networkId 
inner join networks n  on n.id=c.networkId
where sc.RowVer =@v_RandomNumber ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spOrgRegistrationReportData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spOrgRegistrationReportData`( p_OrgId int/* =0 */, p_DateFrom date, p_DateTo date)
BEGIN


SELECT
concat(ifnull(org.Name,'')  , ' ', ifnull(org.Contact,'')) OrgName , Convert(org.CreatedAt, date) CreatedAt ,count(Distinct cmpgn.id) TotalCompaigns,sum(case when ifnull(cmpgn.status,0)=4 then 1 else 0 end)  CompletedCompaigns, sum(case when ifnull(cmpgn.status,0)=1 then 1 else 0 end) InprogressCompaigns, timestampadd(month,-12,now(3)) ExpiryTime,0.0 budget, org.Status,  case when org.Status =1 then 'Active' else 'Disabled' end OrgStatus
FROM organizations org 
left outer join orgpackagedetail opdtl on org.Id= opdtl.OrgId and opdtl.Status= 1
left outer join compaigns cmpgn on cmpgn.OrgId= org.Id -- and... SQLINES DEMO ***
where (p_OrgId=0 OR org.id=p_OrgId) and   Convert(org.CreatedAt, date)>= CONVERT(p_DateFrom, date)  and   Convert(org.CreatedAt, date) <= CONVERT(p_DateTo, date)
--  SQLINES DEMO *** e when @Status=0 then u.Status else  @Status end) and RoleID=2
group by org.Name ,org.Contact ,org.Status,Convert(org.CreatedAt, date);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spPerformUserValidaton` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spPerformUserValidaton`(p_email varchar(100),  p_password varchar(100), p_RoleId int/* =0 */, p_RegistrationSource int /* =0 */)
BEGIN

-- SQLINES DEMO ***  stop access, isnull(ouin.Status,0) AlreadyLoginStatus

SELECT
u.ID, u.OrgId, CONCAT(u.FirstName ,' ',ifnull(u.MiddleName,'') ,' ', u.LastName)  FullName,u.Email, u.Status UserStatus, ouin.MachineIP,
-- SQLINES DEMO *** tus,0)
2 AlreadyLoginStatus, u.Avatar
,u.RoleID,
-- SQLINES DEMO *** D= 2 then 'Subscriber' else 'Admin' end UserRole,case when u.RoleID= 2 then 'Subscriber' else 'Admin' end
ur.Name UserRole,
ifnull(ouin.LoginTime,timestampadd(day,-1,now(3))) LoginTime
FROM users u 
left outer join onlineusers ouin on ouin.UserId=u.ID
left outer join userroles ur  on u.RoleID=ur.ID

 where  u.Email =p_email; -- and  u.Password =@password
 -- and (u.RoleID =@RoleId OR (@RoleId in (5,6) AND u.RoleID <> @RoleId));--  SQLINES DEMO *** n ( 5,6) ) OR @RoleId in ( 5,6))


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spStatsReportData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spStatsReportData`( p_OrgId int/* =0 */,p_budget double/* =0.0 */, p_DateFrom date, p_DateTo date)
BEGIN


SELECT
MONTHNAME(cmpgn.CreatedAt) MName ,MONTH(cmpgn.CreatedAt) MNo  , ifnull(count(cmpgn.id),0) TotalCompaigns,sum(case when cmpgn.status=2 then 1 else 0 end) CompletedCompaigns, sum(case when cmpgn.status=1 then 1 else 0 end) InprogressCompaigns, sum(ifnull(cmpgn.TotalBudget, 0)) budget,   0.0 RevenueIncrease
FROM compaigns cmpgn 
left outer join orgpackagedetail opdtl on cmpgn.OrgId= opdtl.OrgId and opdtl.Status= 1
left outer join compaigns org on cmpgn.OrgId= org.Id -- and... SQLINES DEMO ***
--  SQLINES DEMO ***  org.id=@OrgId) and   Convert(date, org.CreatedAt)>= CONVERT(date, @DateFrom)  and   Convert(date,org.CreatedAt) <= CONVERT(date, @DateTo)
--  SQLINES DEMO *** e when @Status=0 then u.Status else  @Status end) and RoleID=2
group by MONTHNAME(cmpgn.CreatedAt), MONTH(cmpgn.CreatedAt);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spUpdateCompaignStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spUpdateCompaignStatus`(p_id bigint/* =0 */,p_Remarks nvarchar(2000) /* ='' */,p_UserId int /* =0 */, p_Status int/* =0 */)
BEGIN


		update compaigns set status=p_Status, LastUpdatedAt= UTC_TIMESTAMP(3), LastUpdatedBy=p_UserId, Remarks=p_Remarks  
		 where id=p_id and status <> p_Status;	
	select FOUND_ROWS() as updatedCount;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spUpdateNetworkSettingData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spUpdateNetworkSettingData`(p_UserId int,p_NetworkSettingsJSON  json)
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.

DROP TEMPORARY TABLE IF EXISTS tmp_NetworkSettings;
CREATE TEMPORARY TABLE tmp_NetworkSettings (`Id` bigint,`OrgId` bigint, `Name` varchar(500),APIKeySecret varchar(500),Password varchar(50),Sender varchar(500), `APIURI` varchar(500),`APIKey` varchar(500),  `Url` varchar(500),`HashTags` varchar(1000),`Custom1`  text, Custom2 text, NetworkId int,UnitId int,StartTime datetime(3), FinishTime datetime(3),PurchasedQouta int,UsedQuota int,AutoReplyAllowed int, VirtualAccount int,`Status` int ,PostTypeId int,`RowVer` int default(1) , AutoReplyContent varchar(2000),AccountAuthData varchar(1000), BusinessId varchar(1000),m2mIntervalSeconds bigint, smtpserver varchar(80),smtpport varchar(5),smtpcreduser varchar(50),smtpcredpwd varchar(50),smtpsslenabled int,smtpsecretkey varchar(80));
-- SQLINES LICENSE FOR EVALUATION USE ONLY
-- INSERT INTO tmp_NetworkSettings (`Id`, `OrgId` , `Name` ,APIKeySecret ,`Password`,Sender ,`Url`, HashTags,NetworkId ,UnitId ,StartTime , FinishTime ,PurchasedQouta ,UsedQuota,AutoReplyAllowed , VirtualAccount ,`Status`  ,PostTypeId ,AutoReplyContent,AccountAuthData)
INSERT INTO tmp_NetworkSettings (
    `Id`, `OrgId`, `Name`, `APIKeySecret`, `Password`, `Sender`,`APIURI`, `APIKey`,  `Url`, `HashTags`,`Custom1`, `Custom2`,
    `NetworkId`, `UnitId`, `StartTime`, `FinishTime`, `PurchasedQouta`, `UsedQuota`,
    `AutoReplyAllowed`, `VirtualAccount`, `Status`, `PostTypeId`, `AutoReplyContent`, `AccountAuthData`,`m2mIntervalSeconds` ,`BusinessId`,`smtpserver`,`smtpport`,`smtpcreduser`,`smtpcredpwd`,`smtpsslenabled`,`smtpsecretkey`
)
SELECT
    Id,
    IFNULL(OrgId, 0),
    Name,
    ApikeySecret,
    Password,
    Sender,
    Apiuri,
    APIKey,
    Url,
    HashTags,
    Custom1,
	Custom2,
    NetworkId,
    UnitId,
    IFNULL(StartTime, UTC_TIMESTAMP(3)),
    FinishTime,
    IFNULL(PurchasedQouta, 0),
    IFNULL(UsedQuota, 0),
    IFNULL(AutoReplyAllowed, 0),
    IFNULL(VirtualAccount, 0),
    IFNULL(Status, 1),
    PostTypeId,
    AutoReplyContent,
    AccountAuthData,
   IFNULL( m2mIntervalSeconds,0) m2mIntervalSeconds,
   BusinessId,
   smtpserver,
   smtpport,
   smtpcreduser,
   smtpcredpwd,
   ifnull(smtpsslenabled,0) smtpsslenabled,
   smtpsecretkey
FROM
    JSON_TABLE(
        p_NetworkSettingsJSON,
        '$[*]'
        COLUMNS (
            Id BIGINT PATH '$.Id',
            OrgId INT PATH '$.OrgId',
            Name VARCHAR(200) PATH '$.Name',
            ApikeySecret VARCHAR(500) PATH '$.ApikeySecret',
            Password VARCHAR(500) PATH '$.Password',
            Sender VARCHAR(500) PATH '$.Sender',
            Apiuri VARCHAR(500) PATH '$.Apiuri',
            Apikey VARCHAR(500) PATH '$.Apikey',
            Url VARCHAR(200) PATH '$.Url',
            HashTags VARCHAR(500) PATH '$.HashTags',
            Custom1 text PATH '$.Custom1',
			Custom2 text PATH '$.Custom2',
            NetworkId INT PATH '$.NetworkId',
            UnitId INT PATH '$.UnitId',
            StartTime DATETIME PATH '$.StartTime',
            FinishTime DATETIME PATH '$.FinishTime',
            PurchasedQouta INT PATH '$.PurchasedQouta',
            UsedQuota INT PATH '$.UsedQuota',
            AutoReplyAllowed INT PATH '$.AutoReplyAllowed',
            VirtualAccount INT PATH '$.VirtualAccount',
            PostTypeId INT PATH '$.PostTypeId',
            Status INT PATH '$.Status',
            AutoReplyContent VARCHAR(1000) PATH '$.AutoReplyContent',
            AccountAuthData VARCHAR(1000) PATH '$.AccountAuthData',
            m2mIntervalSeconds  BIGINT PATH '$.m2mIntervalSeconds',
            BusinessId VARCHAR(1000) PATH '$.BusinessId',            
			smtpserver VARCHAR(80) PATH '$.smtpserver',
            smtpport VARCHAR(5) PATH '$.smtpport',
            smtpcreduser VARCHAR(80) PATH '$.smtpcreduser',
            smtpcredpwd VARCHAR(80) PATH '$.smtpcredpwd',
			smtpsslenabled INT PATH '$.smtpsslenabled',
			smtpsecretkey VARCHAR(80) PATH '$.smtpsecretkey'   
        )
    ) AS j;

	--  set btwk.status=J.`status`, LastUpdatedAt= UTC_TIMESTAMP(3), LastUpdatedBy=p_UserId;) 
		-- ON J.id = btwk.id 

-- De... SQLINES DEMO ***
-- delete opkg from `orgpackagedetail` opkg where id in ( Select id from tmp_NetworkSettings); -- inner join tmp_NetworkSettings ns on ns.OrgId=opkg.OrgId and opkg.NetworkId=ns.NetworkId;
 -- delete  from `orgpackagedetail`  where id in ( Select Id from tmp_NetworkSettings); -- inner join tmp_NetworkSettings ns on ns.OrgId=opkg.OrgId and opkg.NetworkId=ns.NetworkId;
 UPDATE orgpackagedetail AS opd
JOIN tmp_NetworkSettings AS opdd
  ON opd.Id = opdd.Id
SET
    opd.Name             = opdd.Name,
   -- opd.Description      = opdd.Description,
   -- opd.TargetAudienceId = opdd.TargetAudienceId,
    opd.Password         = opdd.Password,
    opd.Custom1         = opdd.Custom1,  
	opd.Custom2         = opdd.Custom2,  
    opd.URL        		 = opdd.URL,    
	opd.APIURI         	= opdd.APIURI,    
    opd.APIKey         	= opdd.Apikey,    
	opd.VirtualAccount  = opdd.VirtualAccount, 
    opd.Sender          = opdd.Sender,  
	opd.UnitId          = opdd.UnitId, 
    opd.APIKeySecret     = opdd.APIKeySecret,
    opd.HashTags         = opdd.HashTags,
    opd.PurchasedQouta   = opdd.PurchasedQouta,
    opd.AutoReplyContent = opdd.AutoReplyContent,
    opd.AccountAuthData = opdd.AccountAuthData,
    opd.smtpsslenabled = opdd.smtpsslenabled,    
    
     opd.smtpserver = opdd.smtpserver,
     opd.smtpport = ifnull(opdd.smtpport,opd.smtpport),
     opd.smtpcreduser = opdd.smtpcreduser,
     opd.smtpcredpwd = opdd.smtpcredpwd,
     opd.smtpsecretkey = opdd.smtpsecretkey,     
     
    opd.BusinessId       = ifnull(opdd.BusinessId,opd.BusinessId),
   -- opd.UsedQuota        = opdd.UsedQuota,
    opd.StartTime        = IFNULL(opdd.StartTime,  opd.StartTime),
    opd.FinishTime       = IFNULL(opdd.FinishTime, opd.FinishTime),
   -- opd.BufferQuota      = IFNULL(opdd.BufferQuota,opd.BufferQuota),
   -- opd.rowVer           = opd.rowVer + 1,
    opd.status           = ifnull(opdd.status,opd.status) ,
    opd.LastUpdatedAt    = UTC_TIMESTAMP(3),
    opd.LastUpdatedBy    = p_UserId
WHERE opdd.Id > 0;
       
-- SQLINES DEMO *** Pictures
-- SQLINES LICENSE FOR EVALUATION USE ONLY
INSERT INTO `orgpackagedetail` (`OrgId`,`Name` ,`Description`,`TargetAudienceId`,`Password`,`APIKeySecret`,`Custom2`,`Custom1`,`Sender`,`UnitId`,`VirtualAccount`,`URL`,`HashTags`,`NetworkId`,`PurchasedQouta`,`AutoReplyContent`,`ReplyMediaContentId`,`AutoReplyAllowed`,`PostTypeId`,`UsedQuota`,`StartTime`,`FinishTime`,`BufferQuota`,`Status`,`CreatedBy`,`CreatedAt`,`LastUpdatedBy`,`LastUpdatedAt`, `AccountAuthData`,`m2mIntervalSeconds`,`APIURI` ,`APIKey`, `BusinessId`,`smtpserver`,`smtpport`,`smtpcreduser`,`smtpcredpwd`,`smtpsslenabled`,`smtpsecretkey`)
                            select `OrgId`,`Name`, null,null ,`Password`,`APIKeySecret`, Custom2,Custom1,Sender,UnitId,  VirtualAccount,`URL`,HashTags,NetworkId,PurchasedQouta,AutoReplyContent, null, ifnull(AutoReplyAllowed,0),PostTypeId,UsedQuota,StartTime, FinishTime, null, `Status`, p_UserId, UTC_TIMESTAMP(3),p_UserId, UTC_TIMESTAMP(3) , AccountAuthData,ifnull(m2mIntervalSeconds,0) , `APIURI` ,`APIKey`,`BusinessId`,smtpserver,smtpport,smtpcreduser,smtpcredpwd,smtpsslenabled,smtpsecretkey from tmp_NetworkSettings WHERE Id <= 0;
-- if(Last_insert_id()==0
SELECT id FROM orgpackagedetail ORDER BY LastUpdatedAt DESC LIMIT 1;
-- else
-- select Last_insert_id();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spUpdateNetworkStatusAndQoutas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`4dsps`@`%` PROCEDURE `spUpdateNetworkStatusAndQoutas`(p_orgId int/* =0 */,p_NetworksJSON nvarchar(2000) /* ='' */, p_UserId int/* =0 */)
BEGIN
drop temporary table if exists tmp_networkupdates;
create temporary table tmp_networkupdates (Id int  , Status int);

-- Insert into temp
 insert into tmp_networkupdates(Id, Status) 
select Id, Status from JSON_TABLE(p_NetworksJSON, '$[*]' COLUMNS (
                Id int  PATH '$.Id',
                Status int  PATH '$.Status'
                )) as J;
     
     -- Update networks
     UPDATE  networks n1
 JOIN tmp_networkupdates n2
 on n1.Id=n2.Id
     set n1.status = n2.status,  n1.LastUpdatedAt= UTC_TIMESTAMP(3), n1.LastUpdatedBy=p_UserId
where n2.Id > 0;

 select FOUND_ROWS() as updatedCount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spVehiclesServiceData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spVehiclesServiceData`(p_DspId int/* =0 */ ,p_categoryid int/* =0 */ ,p_status int/* =0 */ , p_datefrom datetime/* =now(3) */ , p_dateto datetime/* =now(3) */ )
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.

SELECT
  ir.id, v.fleetcode, v.CategoryId, c.Name CategoryName, concat(v.name, ' ', v.model) vehicleName  , 
   st.Name servicename ,now(3) fleetjoingdate,  ir.CreatedAt, ir.createdBy, ir.RowVer , ir.status
FROM  inspectionreport ir 
left outer join  vehicles v on v.id= ir.vehicleId and ifnull(ir.vehicleId,0) >0 
left outer join  categories c on c.id= v.categoryId and ifnull(v.categoryId,0) >0
left outer join  servicetypes st on st.id= ir.reporttypeid
where  (p_dspid=0 OR p_DspId= v.DSPId) and (p_status=0 OR p_status =v.status) and (p_categoryid=0 OR p_categoryid =v.categoryId)
and (p_RoleId=0 OR p_RoleId = u.roleId) and u.createdAt >= p_datefrom and u.createdAt <= p_dateto; -- and... SQLINES DEMO ***

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spWebApiConfigs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spWebApiConfigs`(p_OrgId int/* =7 */)
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.

select  cnfgs.Id, cnfgs.`key`,cnfgs.`value`, cnfgs.`Description`, cnfgs.OrganizationId
from   `configurations`  cnfgs
where  (cnfgs.status= 1) and (cnfgs.OrganizationId=p_OrgId OR p_OrgId=0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spWebApiCreateCompaignWithNetworkDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spWebApiCreateCompaignWithNetworkDetails`(
    IN p_id BIGINT /* =0 */ ,
    IN p_Discount DOUBLE /* =0 */,
    IN p_TotalBudget DOUBLE /* =0 */,
    IN p_AutoGenerateLeads INT /* =0 */,
    IN p_Orgid INT /* =1 */,
    IN p_Desc VARCHAR(200) /* ='' */,
    IN p_networks JSON,
    IN p_campaignschedules JSON,
    IN p_Name VARCHAR(200) ,
    IN p_title VARCHAR(2000) ,
    IN p_HashTags VARCHAR(2000) ,
    IN p_paymentRef VARCHAR(1000) ,
    IN p_startTime DATETIME(3)  /* =GETutcDATE */,
    IN p_finishTime DATETIME(3)  /* =GETutcDATE */,
    IN p_userId INT ,
    IN p_status INT /* =1 */,
    IN p_targetaudiance VARCHAR(2000)     
)
BEGIN
    DECLARE v_CompaignId BIGINT DEFAULT p_id;
    DECLARE v_RandomNumber INT;
DROP TABLE IF EXISTS tmp_networks;
DROP TABLE IF EXISTS tmp_ExecutionSchedule;
    SET v_RandomNumber = FLOOR(RAND() * 1000) + 10000;

    -- Temp tables
    CREATE TEMPORARY TABLE tmp_networks (
        Id BIGINT DEFAULT 0,
        CompaignId BIGINT,
        NetworkId INT,
        CreatedBy INT,
        CreatedAt DATETIME,
        LastUpdatedBy INT,
        LastUpdatedAt DATETIME,
        Status INT,
        RowVer INT DEFAULT 1,
        posttypejson varchar(100),
        Template TEXT
    );

    CREATE TEMPORARY TABLE tmp_ExecutionSchedule (
        Id BIGINT DEFAULT 0,
        NetworkId INT,
        CompaignDetailId BIGINT,
        IntervalTypeId INT,
        IsFixedTime TINYINT,
        Intervalval INT,
        StartTime DATETIME(3) ,
        FinishTime DATETIME(3) ,
        CreatedBy INT,
        CreatedAt DATETIME,
        LastUpdatedBy INT,
        LastUpdatedAt DATETIME,
        Status INT,
        RowVer INT DEFAULT 1,
        Budget DOUBLE,
        messageCount BIGINT,
        days VARCHAR(40)
    );
 

    -- Insert into tmp_Details
    IF (JSON_LENGTH(p_networks) > 0) THEN
        INSERT INTO tmp_networks (Id, CompaignId, NetworkId, CreatedBy, CreatedAt, LastUpdatedBy, LastUpdatedAt, Status, RowVer,posttypejson, Template)
        SELECT 
            IFNULL(id,0),
            IFNULL(compaignId,0),
            IFNULL(networkId,0),
            IFNULL(createdBy,0),
            UTC_TIMESTAMP(),
            IFNULL(lastUpdatedBy, createdBy),
            UTC_TIMESTAMP(),
            IFNULL(status,1),
            v_RandomNumber
            ,posttypejson
            ,Template 
        FROM JSON_TABLE(p_networks, '$[*]'
            COLUMNS (
                id BIGINT PATH '$.id',
                compaignId BIGINT PATH '$.compaignId',
                networkId INT PATH '$.networkId',
                createdBy INT PATH '$.createdBy',
                createdAt DATETIME PATH '$.createdAt',
                lastUpdatedBy INT PATH '$.lastUpdatedBy',
                status INT PATH '$.status',
                posttypejson varchar(100) PATH '$.posttypejson',
                Template TEXT PATH '$.template'
            )
        ) AS jt;
    END IF;

    -- Insert into tmp_ExecutionSchedule and tmp_Days
    IF (JSON_LENGTH(p_campaignschedules) > 0) THEN
        INSERT INTO tmp_ExecutionSchedule
            (Id, NetworkId, CompaignDetailId, IntervalTypeId, IsFixedTime, Intervalval, StartTime, FinishTime, CreatedBy, CreatedAt, LastUpdatedBy, LastUpdatedAt, Status, RowVer, Budget, messageCount,days)
        SELECT 
            IFNULL(id,0),
            networkId,
            IFNULL(compaignDetailId,0),
            IFNULL(intervalTypeId,0),
            IFNULL(isFixedTime,0),
            IFNULL(Intervalval,0),
            IFNULL(startTime, UTC_TIMESTAMP()),
            finishTime,
            p_userId,
            UTC_TIMESTAMP(),
            p_userId,
            UTC_TIMESTAMP(),
            IFNULL(status,1),
            v_RandomNumber,
            budget,
            messageCount,
            days
        FROM JSON_TABLE(p_campaignschedules, '$[*]'
            COLUMNS (
                id BIGINT PATH '$.id',
                compaignDetailId BIGINT PATH '$.compaignDetailId',
                networkId INT PATH '$.networkId',
                intervalTypeId INT PATH '$.intervalTypeId',
                isFixedTime TINYINT PATH '$.isFixedTime',
                Intervalval INT PATH '$.intervalval',
                startTime DATETIME(3)  PATH '$.startTime',
                finishTime DATETIME(3)  PATH '$.finishTime',
                createdBy INT PATH '$.createdBy',
                lastUpdatedBy INT PATH '$.lastUpdatedBy',
                status INT PATH '$.status',
                budget DOUBLE PATH '$.budget',
                messageCount BIGINT PATH '$.messageCount',
                days VARCHAR(40) PATH '$.days'
            )
        ) AS jt ;  

       
    END IF;

    -- Insert or update Compaign
    IF (p_id > 0) THEN
        UPDATE compaigns
        SET 
            Status = p_status,
            Description = IF(CHAR_LENGTH(p_Desc) > 0, p_Desc, Description),
            AutoGenerateLeads = p_AutoGenerateLeads,
            TotalBudget = p_TotalBudget,
            Discount = p_Discount,
            LastUpdatedAt = UTC_TIMESTAMP(),
            LastUpdatedBy = p_userId,
            paymentRef= p_paymentRef,
            HashTags = IF(CHAR_LENGTH(p_HashTags) > 0, p_HashTags, HashTags),
            Title = IF(CHAR_LENGTH(p_title) > 0, p_title, Title),
            Name = IF(CHAR_LENGTH(p_Name) > 0, p_Name, Name)
        WHERE id = p_id;

        IF (ROW_COUNT() <= 0) THEN
            SET v_CompaignId = 0;
        END IF;
    ELSE
        INSERT INTO compaigns
            (Name, Description, Title, HashTags, OrgId, CreatedBy, CreatedAt, LastUpdatedBy, FinishTime, StartTime, ApprovalTime, LastUpdatedAt, Status, RowVer, AutoGenerateLeads, TotalBudget, Discount,targetaudiance,paymentRef)
        VALUES
            (p_Name, p_Desc, p_title, p_HashTags, p_Orgid, p_userId, UTC_TIMESTAMP(), p_userId, p_finishTime, p_startTime, UTC_TIMESTAMP(), UTC_TIMESTAMP(), p_status, 1, p_AutoGenerateLeads, p_TotalBudget, p_Discount,p_targetaudiance,p_paymentRef);

        SET v_CompaignId = LAST_INSERT_ID();
    END IF;

    -- Insert into CompaignNetwork
    IF (v_CompaignId > 0) THEN
        INSERT INTO compaignnetwork (CompaignId, NetworkId, `Desc`, `Code`, CreatedBy, CreatedAt, LastUpdatedBy, LastUpdatedAt, Status, RowVer,posttypejson,Template)
        SELECT 
            IF(CompaignId<=0, v_CompaignId, CompaignId),
            NetworkId,
            NULL,
            TRIM(CAST(v_RandomNumber AS CHAR)),
            p_userId,
            CreatedAt,
            LastUpdatedBy,
            LastUpdatedAt,
            Status,
            RowVer,
            posttypejson,
            Template
        FROM tmp_networks WHERE Id <= 0;

        -- Insert into CompaignExecutionSchedule
        INSERT INTO compaignexecutionschedule (NetworkId, CompaignDetailId, Intervalval, IntervalTypeId, FinishTime, StartTime, LastUpdatedAt, CreatedBy, CreatedAt, LastUpdatedBy, Status, RowVer, Budget, messageCount,days)
        SELECT 
            es.NetworkId,
            case when IFNULL(es.CompaignDetailId,0)<=0 then cdtl.Id else es.CompaignDetailId end,
            es.Intervalval,
            es.IntervalTypeId,
            es.FinishTime,
            es.StartTime,
            es.LastUpdatedAt,
            p_userId,
            es.CreatedAt,
            p_userId,
            es.Status,
            es.RowVer,
            es.Budget,
            es.messageCount,
             es.days
        FROM tmp_ExecutionSchedule es
        JOIN compaignnetwork cdtl ON (es.RowVer = cdtl.RowVer OR es.CompaignDetailId = cdtl.Id) AND es.NetworkId = cdtl.NetworkId
        WHERE cdtl.CompaignId = v_CompaignId AND es.Id <= 0;
     
    END IF;

    -- Return new or updated CompaignId
    SELECT v_CompaignId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spWebApiPOSGetCompaigns` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spWebApiPOSGetCompaigns`(p_Id bigint/* =0 */ ,p_userid int/* =0 */, p_networkId int/* =0 */ ,p_orgId int/* =0 */ ,p_status int/* =0 */, p_name varchar(200)/* ='' */,  p_DateFrom date/* = getutcdate */, p_DateTo date/* = getutcdate */)
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.
SET SESSION group_concat_max_len = 1000000;
select DIstinct cmpns.Id,0 CompaignDetailId, 0 NetworkId,ifnull(cmpns.OrgId,0) OrgId,ifnull(cmpns.Name,cmpns.Title) CompaignName,ifnull(cmpns.Description,'') CompaignDesc, ifnull(cmpns.title,'') Compaigntitle, ifnull(orgs.Name ,ifnull(cmpns.Title,'')) orgName,ifnull(ctis.name,'') CityName,'' NetworkName,ifnull(cmpns.StartTime,UTC_TIMESTAMP(3))StartTime  ,ifnull(cmpns.FinishTime,UTC_TIMESTAMP(3)) FinishTime , ifnull(orgs.logoAvatar, (select ProfileImage from noimage
limit 1) ) logoAvatar, AutoGenerateLeads, cmpns.HashTags,ifnull(Discount,0) Discount,ROUND(ifnull(TotalBudget,0),2)  TotalBudget, ifnull(cmpns.TaxApplicable,0) TaxApplicable, 
cmpns.LastUpdatedAt,cmpns.CreatedBy, orgs.Contact, cmpns.Status, targetaudiance,
(select 
    concat('[',
        GROUP_CONCAT(
            JSON_OBJECT(    
                'id', cdtl.id
               --  ,'compaignQouta', 0
              --   ,'freeQouta', 0
                 ,'avatar', usrs.avatar
                 ,'compaignFrom', concat(ifnull(usrs.FirstName,'') ,' ' , ifnull(usrs.LastName,''))
                 ,'lastUpdatedAt', cdtl.LastUpdatedAt
                 ,'createdAt', cdtl.CreatedAt
                 ,'networkName', ifnull(ntwrk.Name,'')
                  ,'template', ifnull(cdtl.Template,'')
                 ,'networkId', ntwrk.Id
                 )
            SEPARATOR ',')
    ,']') as json
    from compaignnetwork cdtl 
left outer join networks ntwrk  on ntwrk.Id=cdtl.networkId
left outer join users usrs  on cdtl.CreatedBy=usrs.Id
where cdtl.CompaignId=cmpns.Id and cdtl.Status=1 order by cdtl.id DESC) compaignsdetails
,( Select concat('[',
        GROUP_CONCAT(
            JSON_OBJECT(    
                'id', scdl.id
                ,'CompaignDetailId', scdl.CompaignDetailId
                ,'NetworkId', scdl.NetworkId
                 ,'Interval',  scdl.Intervalval
              --   ,'intervaltypename',  itypes.Name
                 ,'IntervalTypeId',  scdl.IntervalTypeId
                 ,'avatar',  usrs.avatar
                 ,'scheduleFrom', concat(ifnull(usrs.FirstName,'') ,' ' , ifnull(usrs.LastName,''))  
                 ,'StartTime', scdl.StartTime
                 ,'FinishTime', scdl.FinishTime
                 ,'budget', ifnull(scdl.budget,0)
                 ,'days', scdl.days
                --  ,'days', scdl.days, -- (Select DISTINCT GROUP_CONCAT(daynumber) from CompaignScheduleDays csdys  where csdys.CompaignScheduleId=scdl.Id)
                 ,'MessageCount', ifnull(scdl.MessageCount,0)               
               --  ,'lastUpdatedAt', cdtl.LastUpdatedAt
                 ,'createdAt', cdtl.CreatedAt
              --   ,'networkName', ntwks.Name
                -- ,'networkId', ntwks.Id
                 )
            SEPARATOR ',')
    ,']') as json
from compaignexecutionschedule scdl
left outer join users usrs  on scdl.CreatedBy=usrs.Id
left outer join intervaltypes itypes   on itypes.Id=scdl.IntervalTypeId
--  SQLINES DEMO *** mpaignScheduleDays dys with(nolock)  on dys.CompaignScheduleId=scdl.Id
where scdl.status=1 and  scdl.CompaignDetailId in ( Select icdtl.id from compaignnetwork icdtl where icdtl.CompaignId=cmpns.Id)  order by cdtl.id DESC
 ) compaignschedules
 ,(select 
    concat('[',
        GROUP_CONCAT(
            JSON_OBJECT(    
                'id', images.Id 
                ,'image', replace(replace(name,'wwwroot',''),'//','/')              
                 )
            SEPARATOR ',')
    ,']') as json from mediacontent images where images.CompaignId=cmpns.Id and length(name) > 4) as attachments
from   compaigns cmpns 
left outer join compaignnetwork cdtl  on cdtl.CompaignId=cmpns.Id and cdtl.status=1
-- left outer join networks ntwks on ntwks.Id=cdtl.NetworkId and ntwks.status=1
left outer join organizations orgs  on orgs.Id=cmpns.OrgId and orgs.status=1
left outer join orgpackagedetail orgpkg  on orgpkg.OrgId=cmpns.OrgId and cdtl.NetworkId=orgpkg.NetworkId
left outer join cities ctis  on ctis.Id=orgs.CityId and ctis.status=1
where (p_Id=0 or cmpns.id=p_Id) and (p_status=0 OR cmpns.`Status` =p_status) --  and cmpns.id=220230 -- 220225
 and  Convert(cmpns.StartTime, date)>= CONVERT(p_DateFrom, date)   and  Convert(cmpns.StartTime, date) <= CONVERT(p_DateTo, date) 
 and (p_orgId=0 OR cmpns.OrgId=p_orgId) and (p_userid=0 OR cmpns.CreatedBy=p_userid)  and (p_networkId=0 OR orgpkg.NetworkId=p_networkId) 
 and  (CHAR_LENGTH(RTRIM(ifnull(p_name,''))) <=0  OR cmpns.name COLLATE utf8mb4_general_ci like Concat('%', RTRIM(LTRIM(p_name)) ,'%') OR cmpns.Description COLLATE utf8mb4_general_ci like Concat('%', RTRIM(LTRIM(p_name)) ,'%') OR cmpns.HashTags COLLATE utf8mb4_general_ci like Concat('%', RTRIM(LTRIM(p_name)) ,'%')) --  SQLINES DEMO *** e ''@name
order by cmpns.Id DESC ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spWebApiPOSGetCompaignsDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `spWebApiPOSGetCompaignsDetails`(p_CompaignId bigint/* =0 */ )
BEGIN
-- SQLINES DEMO *** ded to prevent extra result sets from
-- SQLINES DEMO *** SELECT statements.

select DIstinct cmpns.Id,0 NetworkId,ifnull(cdtl.Id,0) CompaignDetailId, ifnull(cmpns.OrgId,0) OrgId,ifnull(cmpns.Name,cmpns.Title) CompaignName,ifnull(cmpns.Description,'') CompaignDesc, ifnull(cmpns.title,'') Compaigntitle, ifnull(cmpns.OrgId,ifnull(orgs.Name,'')) orgName,ifnull(ctis.name,'') CityName,ifnull(ntwks.name,'') NetworkName,
ifnull(cmpns.StartTime,UTC_TIMESTAMP(3))StartTime  ,ifnull(cmpns.FinishTime,UTC_TIMESTAMP(3)) FinishTime , ifnull(orgs.logoAvatar,'' ) logoAvatar
,cmpns.LastUpdatedAt,cmpns.CreatedBy,
(select 
    concat('[',
        GROUP_CONCAT(
            JSON_OBJECT(    
                'id', cdtl.id
                ,'compaignQouta', ifnull(cdtl.qouta,0)
                ,'freeQouta', cdtl.FreeQouta
                 ,'avatar', usrs.avatar
                 ,'userName', concat(ifnull(usrs.FirstName,'') ,' ' , ifnull(usrs.LastName,''))
                  ,'compaignFrom', concat(ifnull(usrs.FirstName,'') ,' ' , ifnull(usrs.LastName,''))
                 ,'lastUpdatedAt', cdtl.LastUpdatedAt
                 ,'createdAt', cdtl.CreatedAt
                 ,'networkName', ntwrk.Name
                 ,'networkId', ntwrk.Id
                 )
            SEPARATOR ',')
    ,']') as json
from compaigndetails cdtl 
left outer join networks ntwrk  on ntwrk.Id=cdtl.networkId
left outer join users usrs  on cdtl.CreatedBy=usrs.Id
where cdtl.CompaignId=3 and cdtl.Status=1  order by cdtl.id DESC ) compaigns, orgs.Contact, cmpns.Status
from   compaigns cmpns 
left outer join compaigndetails cdtl  on cdtl.CompaignId=cmpns.Id and cdtl.status=1
left outer join networks ntwks  on ntwks.Id=cdtl.NetworkId and ntwks.status=1
left outer join organizations orgs  on orgs.Id=cmpns.OrgId and orgs.status=1
left outer join cities ctis on ctis.Id=orgs.CityId and ctis.status=1
where (p_CompaignId=0 OR cmpns=p_CompaignId)
 order by cmpns.Id DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:37
