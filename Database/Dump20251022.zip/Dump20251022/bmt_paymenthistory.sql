CREATE DATABASE  IF NOT EXISTS `bmt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bmt`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bmt
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `paymenthistory`
--

DROP TABLE IF EXISTS `paymenthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paymenthistory` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `PaymentId` bigint NOT NULL,
  `CompaignId` bigint DEFAULT NULL,
  `OrgId` int DEFAULT NULL,
  `TransactionCode` varchar(20) DEFAULT NULL,
  `TransactionId` varchar(20) DEFAULT NULL,
  `CustomerId` varchar(20) DEFAULT NULL,
  `CustomerProfileId` varchar(50) DEFAULT NULL,
  `ZipCode` varchar(6) DEFAULT NULL,
  `InvoiceCode` varchar(20) DEFAULT NULL,
  `DeliveryCharges` float DEFAULT NULL,
  `TaxAmount` float DEFAULT NULL,
  `TotalChargedAmnt` float DEFAULT NULL,
  `PaymentMethodId` tinyint NOT NULL,
  `Birthdate` datetime DEFAULT NULL,
  `ShippingAddress` varchar(500) DEFAULT NULL,
  `BillingAddress` varchar(500) DEFAULT NULL,
  `LastName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `CustomerEmail` varchar(50) NOT NULL,
  `CardExiry` varchar(7) DEFAULT NULL,
  `CVC` varchar(3) DEFAULT NULL,
  `CardNumber` varchar(16) DEFAULT NULL,
  `CardHolderTitle` varchar(50) DEFAULT NULL,
  `DishonorTime` datetime DEFAULT NULL,
  `ValueTime` datetime DEFAULT NULL,
  `TransactionResponse` varchar(4000) DEFAULT NULL,
  `Note` varchar(1000) DEFAULT NULL,
  `TransactionTime` datetime DEFAULT NULL,
  `ArchiveTime` datetime DEFAULT NULL,
  `Status` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_PaymentHistory_PaymentId` (`PaymentId`),
  KEY `IX_PaymentHistory_CustomerEmail` (`CustomerEmail`),
  CONSTRAINT `FK_PaymentHistory_PaymentId` FOREIGN KEY (`PaymentId`) REFERENCES `payment` (`Id`),
  CONSTRAINT `CHK_PaymentHistory_Status` CHECK ((`Status` in (0,1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymenthistory`
--

LOCK TABLES `paymenthistory` WRITE;
/*!40000 ALTER TABLE `paymenthistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymenthistory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-22 16:46:29
